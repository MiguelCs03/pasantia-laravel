(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[43],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/TipoDocumentoAlmacen.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Farmacia/TipoDocumentoAlmacen.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      // paginación
      pageOptions: [50, 100, 200, 500],
      currentPage: 1,
      totalRows: 1,
      perPage: 50,
      buscar: '',
      overlayTable: false,
      arrayTipoDoc: [],
      fields: [{
        key: 'tipo_documento',
        label: 'tipo de documento'
      }, {
        key: 'tda_origen',
        label: 'origen documento'
      }, {
        key: 'tda_descripcion',
        label: 'descripción documento'
      }, {
        key: 'tda_activo',
        label: 'estado',
        "class": 'text-center'
      }, {
        key: 'opcion',
        label: 'opción',
        "class": 'text-center text-nowrap'
      }],
      estado: [{
        0: 'INACTIVO',
        1: 'ACTIVO'
      }, {
        0: 'light-danger',
        1: 'light-success'
      }],
      arrayTipo: [{
        value: 'EGR',
        text: 'EGRESO'
      }, {
        value: 'ING',
        text: 'INGRESO'
      }],
      objTipoDocAlmacen: {},
      overlayStorage: false,
      modalStorage: false,
      title: ''
    };
  },
  mounted: function mounted() {
    this.listarTipoDoc();
  },
  methods: {
    abrirModal: function abrirModal(item) {
      if (item != null) {
        this.title = 'EDITAR TIPO DOCUMENTO ALMACEN';
        this.objTipoDocAlmacen = {
          id: item.id_tipo_doc_almacen,
          tipo: item.tipo_documento,
          origen: item.tda_origen,
          descripcion: item.tda_descripcion
        };
      } else {
        this.title = 'NUEVO TIPO DOCUMENTO ALMACEN';
        this.objTipoDocAlmacen = {
          id: 0,
          tipo: 'EGR'
        };
      }

      this.modalStorage = true;
    },
    listarTipoDoc: function listarTipoDoc() {
      var _this = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarTipoDocAlmacen?perPage=' + this.perPage + '&page=' + this.currentPage + '&buscar=' + this.buscar).then(function (res) {
        _this.arrayTipoDoc = res.data.data;
        _this.totalRows = res.data.total;
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this.overlayTable = false;
      });
    },
    guardarTipoDoc: function guardarTipoDoc() {
      var _this2 = this;

      this.overlayStorage = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/guardarTipoDocAlmacen', {
        'id': this.objTipoDocAlmacen.id,
        'tipo': this.objTipoDocAlmacen.tipo,
        'origen': this.objTipoDocAlmacen.origen,
        'descripcion': this.objTipoDocAlmacen.descripcion
      }).then(function (res) {
        _this2.listarTipoDoc();

        _this2.modalStorage = false;

        _this2.pop_up('Éxito', 'Guardado Correctamente', 'success');
      })["catch"](function (err) {
        console.log(err);

        _this2.pop_up('Error', 'Error al Guardar', 'error');
      })["finally"](function () {
        _this2.overlayStorage = false;
      });
    },
    cambiarEstadoTipoDoc: function cambiarEstadoTipoDoc(item) {
      var _this3 = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/cambiarEstadoTipoDocAlmacen', {
        'id': item.id_tipo_doc_almacen,
        'estado': item.tda_activo == 1 ? 0 : 1
      }).then(function (res) {
        _this3.listarTipoDoc();

        _this3.pop_up('Éxito', 'Guardado Correctamente', 'success');
      })["catch"](function (err) {
        console.log(err);
        _this3.overlayTable = false;

        _this3.pop_up('Error', 'Error al Guardar', 'error');
      });
    },
    pop_up: function pop_up(title, text, icon) {
      this.$swal({
        title: title,
        text: text,
        icon: icon,
        showConfirmButton: false,
        timer: 2000,
        customClass: {
          confirmButton: 'btn btn-primary'
        },
        buttonsStyling: false
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/TipoDocumentoAlmacen.vue?vue&type=template&id=eaf455dc&":
/*!*******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Farmacia/TipoDocumentoAlmacen.vue?vue&type=template&id=eaf455dc& ***!
  \*******************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-card",
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-button",
                    {
                      attrs: { variant: "outline-success" },
                      on: {
                        click: function ($event) {
                          return _vm.abrirModal(null)
                        },
                      },
                    },
                    [_vm._v(" Nuevo Tipo Documento ")]
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-input-group",
                    [
                      _c("b-form-input", {
                        attrs: { placeholder: "Buscar...", state: true },
                        model: {
                          value: _vm.buscar,
                          callback: function ($$v) {
                            _vm.buscar = $$v
                          },
                          expression: "buscar",
                        },
                      }),
                      _vm._v(" "),
                      _c(
                        "b-input-group-append",
                        [
                          _c(
                            "b-button",
                            {
                              attrs: { variant: "outline-success" },
                              on: {
                                click: function ($event) {
                                  return _vm.listarTipoDoc()
                                },
                              },
                            },
                            [_vm._v(" Buscar ")]
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayTable,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c("b-table", {
            attrs: {
              hover: "",
              striped: "",
              responsive: "",
              bordered: "",
              small: "",
              "no-border-collapse": "",
              items: _vm.arrayTipoDoc,
              fields: _vm.fields,
            },
            scopedSlots: _vm._u([
              {
                key: "cell(tda_activo)",
                fn: function (data) {
                  return [
                    _c(
                      "b-badge",
                      {
                        attrs: { variant: _vm.estado[1][data.item.tda_activo] },
                      },
                      [
                        _vm._v(
                          "\n                    " +
                            _vm._s(_vm.estado[0][data.item.tda_activo]) +
                            "\n                "
                        ),
                      ]
                    ),
                  ]
                },
              },
              {
                key: "cell(opcion)",
                fn: function (data) {
                  return [
                    _c(
                      "b-button",
                      {
                        staticClass: "btn-icon rounded-circle text-center",
                        attrs: {
                          variant: data.item.tda_activo
                            ? "flat-danger"
                            : "flat-success",
                          title: data.item.tda_activo
                            ? "desactivar"
                            : "activar",
                        },
                        on: {
                          click: function ($event) {
                            return _vm.cambiarEstadoTipoDoc(data.item)
                          },
                        },
                      },
                      [
                        _c("feather-icon", {
                          attrs: {
                            icon: data.item.tda_activo
                              ? "LockIcon"
                              : "UnlockIcon",
                          },
                        }),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-button",
                      {
                        staticClass: "btn-icon rounded-circle text-center",
                        attrs: { variant: "flat-info", title: "editar" },
                        on: {
                          click: function ($event) {
                            return _vm.abrirModal(data.item)
                          },
                        },
                      },
                      [_c("feather-icon", { attrs: { icon: "EditIcon" } })],
                      1
                    ),
                  ]
                },
              },
            ]),
          }),
          _vm._v(" "),
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { cols: "2" } },
                [
                  _c(
                    "b-form-group",
                    { staticClass: "mb-0" },
                    [
                      _c(
                        "label",
                        { staticClass: "d-inline-block text-sm-left mr-50" },
                        [_vm._v("Por página")]
                      ),
                      _vm._v(" "),
                      _c("b-form-select", {
                        staticClass: "w-50",
                        attrs: { size: "sm", options: _vm.pageOptions },
                        on: {
                          input: function ($event) {
                            return _vm.listarTipoDoc()
                          },
                        },
                        model: {
                          value: _vm.perPage,
                          callback: function ($$v) {
                            _vm.perPage = $$v
                          },
                          expression: "perPage",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-col", { attrs: { cols: "10" } }, [
                _c(
                  "span",
                  { staticStyle: { float: "right" } },
                  [
                    _c("b-pagination", {
                      staticClass: "my-0",
                      attrs: {
                        "total-rows": _vm.totalRows,
                        "per-page": _vm.perPage,
                        align: "center",
                        size: "sm",
                      },
                      model: {
                        value: _vm.currentPage,
                        callback: function ($$v) {
                          _vm.currentPage = $$v
                        },
                        expression: "currentPage",
                      },
                    }),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: {
            "hide-footer": "",
            centered: "",
            title: _vm.title,
            size: "md",
          },
          model: {
            value: _vm.modalStorage,
            callback: function ($$v) {
              _vm.modalStorage = $$v
            },
            expression: "modalStorage",
          },
        },
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Tipo Documento ")]),
                      _vm._v(" "),
                      _c("b-form-select", {
                        attrs: {
                          options: _vm.arrayTipo,
                          state: _vm.objTipoDocAlmacen.tipo != null,
                        },
                        model: {
                          value: _vm.objTipoDocAlmacen.tipo,
                          callback: function ($$v) {
                            _vm.$set(_vm.objTipoDocAlmacen, "tipo", $$v)
                          },
                          expression: "objTipoDocAlmacen.tipo",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Origen ")]),
                      _vm._v(" "),
                      _c("b-form-input", {
                        attrs: {
                          placeholder: "Origen",
                          state: _vm.objTipoDocAlmacen.origen != null,
                        },
                        model: {
                          value: _vm.objTipoDocAlmacen.origen,
                          callback: function ($$v) {
                            _vm.$set(_vm.objTipoDocAlmacen, "origen", $$v)
                          },
                          expression: "objTipoDocAlmacen.origen",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "12" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Descripción ")]),
                      _vm._v(" "),
                      _c("b-form-textarea", {
                        attrs: {
                          rows: "3",
                          placeholder: "Descripción",
                          state: _vm.objTipoDocAlmacen.descripcion != null,
                        },
                        model: {
                          value: _vm.objTipoDocAlmacen.descripcion,
                          callback: function ($$v) {
                            _vm.$set(_vm.objTipoDocAlmacen, "descripcion", $$v)
                          },
                          expression: "objTipoDocAlmacen.descripcion",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayStorage,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-left",
              attrs: { variant: "outline-danger" },
              on: {
                click: function ($event) {
                  _vm.modalStorage = false
                },
              },
            },
            [_vm._v(" Cancelar ")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-right",
              attrs: { variant: "outline-success" },
              on: {
                click: function ($event) {
                  return _vm.guardarTipoDoc()
                },
              },
            },
            [_vm._v(" Guardar ")]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/Farmacia/TipoDocumentoAlmacen.vue":
/*!******************************************************************!*\
  !*** ./resources/js/src/views/Farmacia/TipoDocumentoAlmacen.vue ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TipoDocumentoAlmacen_vue_vue_type_template_id_eaf455dc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TipoDocumentoAlmacen.vue?vue&type=template&id=eaf455dc& */ "./resources/js/src/views/Farmacia/TipoDocumentoAlmacen.vue?vue&type=template&id=eaf455dc&");
/* harmony import */ var _TipoDocumentoAlmacen_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TipoDocumentoAlmacen.vue?vue&type=script&lang=js& */ "./resources/js/src/views/Farmacia/TipoDocumentoAlmacen.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _TipoDocumentoAlmacen_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TipoDocumentoAlmacen_vue_vue_type_template_id_eaf455dc___WEBPACK_IMPORTED_MODULE_0__["render"],
  _TipoDocumentoAlmacen_vue_vue_type_template_id_eaf455dc___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/Farmacia/TipoDocumentoAlmacen.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/Farmacia/TipoDocumentoAlmacen.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/src/views/Farmacia/TipoDocumentoAlmacen.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TipoDocumentoAlmacen_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./TipoDocumentoAlmacen.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/TipoDocumentoAlmacen.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TipoDocumentoAlmacen_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/Farmacia/TipoDocumentoAlmacen.vue?vue&type=template&id=eaf455dc&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/src/views/Farmacia/TipoDocumentoAlmacen.vue?vue&type=template&id=eaf455dc& ***!
  \*************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TipoDocumentoAlmacen_vue_vue_type_template_id_eaf455dc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./TipoDocumentoAlmacen.vue?vue&type=template&id=eaf455dc& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/TipoDocumentoAlmacen.vue?vue&type=template&id=eaf455dc&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TipoDocumentoAlmacen_vue_vue_type_template_id_eaf455dc___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TipoDocumentoAlmacen_vue_vue_type_template_id_eaf455dc___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);