(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[45],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/GestionDocumental/DocumentoPersonal.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/GestionDocumental/DocumentoPersonal.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! leaflet */ "./node_modules/leaflet/dist/leaflet-src.js");
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(leaflet__WEBPACK_IMPORTED_MODULE_3__);



//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      // paginación
      pageOptions: [50, 100, 200, 500],
      currentPage: 1,
      totalRows: 1,
      perPage: 50,
      buscar: '',
      overlayTable: false,
      arrayPersonal: [],
      fields: [{
        key: 'p_nombre',
        label: 'persona'
      }, {
        key: 'ca_nombre',
        label: 'cargo'
      }, {
        key: 'p_telefono',
        label: 'teléfono',
        "class": 'text-center'
      }, {
        key: 'p_ci',
        label: 'ci',
        "class": 'text-center'
      }, {
        key: 'p_nacimiento',
        label: 'fecha nac.',
        "class": 'text-center'
      }, {
        key: 'id_cargo',
        label: 'edad',
        "class": 'text-center'
      }, {
        key: 'p_activo',
        label: 'estado',
        "class": 'text-center'
      }, {
        key: 'opcion',
        label: 'opción',
        "class": 'text-center text-nowrap'
      }],
      estado: [{
        0: 'INACTIVO',
        1: 'ACTIVO'
      }, {
        0: 'light-danger',
        1: 'light-success'
      }],
      modalAdjuntarDocumento: false,
      overlayStore: false,
      documento: '',
      tipoDocumento: null,
      archivo: null,
      file: null,
      id: 0,
      modalAnulacion: false,
      id_gestion_doc: null,
      modalDocumento: false,
      arrayDocPersona: [],
      fields2: [{
        key: 'gd_nombre',
        label: 'nombre documento'
      }, {
        key: 'nombre',
        label: 'tipo documento'
      }, {
        key: 'opcion',
        label: 'opción',
        "class": 'text-center text-nowrap'
      }],
      arrayTipoDocumento: [],
      persona: ''
    };
  },
  mounted: function mounted() {
    this.listarPersonal();
    this.listarTipoDocumento();
  },
  methods: {
    listarPersonal: function listarPersonal() {
      var _this = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarPersona?perPage=' + this.perPage + '&page=' + this.currentPage + '&buscar=' + this.buscar).then(function (res) {
        _this.arrayPersonal = [];
        _this.arrayPersonal = res.data.data;
        _this.totalRows = res.data.total;
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this.overlayTable = false;
      });
    },
    listarTipoDocumento: function listarTipoDocumento() {
      var _this2 = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarTiposDocumentos').then(function (res) {
        _this2.arrayTipoDocumento = res.data.map(function (item) {
          return {
            value: item.id_tipo_documento,
            text: item.nombre
          };
        });
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this2.overlayTable = false;
      });
    },
    guardarDocumento: function guardarDocumento() {
      var _this3 = this;

      this.overlayStore = true;
      var formData = new FormData();
      formData.append('nombre', this.documento);
      formData.append('id_tipo_documento', this.tipoDocumento);
      formData.append('file', this.archivo);
      formData.append('id', this.id);
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/guardarDocumento', formData).then(function (res) {
        _this3.listarPersonal();

        _this3.modalAdjuntarDocumento = false;

        _this3.pop_up('Éxito', 'Documento Guardado Correctamente', 'success');
      })["catch"](function (err) {
        console.log(err);
        if (err.response.status == 422) _this3.pop_up('Error', 'Los Campos son Obligatorios', 'error');else _this3.pop_up('Error', 'Error al Guardar, intente más tarde!!!', 'error');
      })["finally"](function () {
        _this3.overlayStore = false;
      });
    },
    abrirModalDocumento: function abrirModalDocumento(item) {
      this.id = item.id_persona;
      this.file = null;
      this.archivo = null;
      this.documento = '';
      this.modalAdjuntarDocumento = true;
    },
    cargarArchivo: function cargarArchivo(event) {
      this.archivo = event.target.files[0];

      if (this.archivo) {
        var tipoArchivo = this.archivo.type;

        if (!["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"].includes(tipoArchivo)) {
          this.pop_up('Error', 'Documento no válido', 'error');
          this.archivo = null;
          this.file = null;
          return;
        }
      }
    },
    abrirModalDocPersona: function abrirModalDocPersona(item) {
      var _this4 = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarDocPersona?id=' + item.id_persona).then(function (res) {
        _this4.persona = item.p_paterno + ' ' + item.p_materno + ' ' + item.p_nombre;
        _this4.arrayDocPersona = res.data;
        _this4.modalDocumento = true;
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this4.overlayTable = false;
      });
    },
    descargarDoc: function descargarDoc(item) {
      var url = item.gd_path;
      var link = document.createElement('a');
      link.href = url;
      link.target = '_blank';
      link.click();
      this.modalDocumento = false;
    },
    abrirModalAnulacion: function abrirModalAnulacion(item) {
      console.log(item);
      this.id_gestion_doc = item.id_gestion_doc;
      this.modalAnulacion = true;
    },
    anularDOC: function anularDOC() {
      var _this5 = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/anularDOC', {
        id_gestion_doc: this.id_gestion_doc
      }).then(function () {
        _this5.modalAnulacion = false;
        _this5.modalDocumento = false;

        _this5.pop_up('Anulado', 'El Documento ha sido eliminado exitosamente.', 'success');
      })["catch"](function (err) {
        console.error(err);

        _this5.pop_up('Error', 'Ocurrió un error al intentar eliminar el Documento.', 'error');
      })["finally"](function () {
        _this5.overlayTable = false;
      });
    },
    pop_up: function pop_up(title, text, icon) {
      this.$swal({
        title: title,
        text: text,
        icon: icon,
        showConfirmButton: false,
        timer: 2000,
        customClass: {
          confirmButton: 'btn btn-primary'
        },
        buttonsStyling: false
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/GestionDocumental/DocumentoPersonal.vue?vue&type=template&id=3eff92fa&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/GestionDocumental/DocumentoPersonal.vue?vue&type=template&id=3eff92fa& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-card",
        [
          _c(
            "b-row",
            [
              _c("b-col", { attrs: { md: "6" } }),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-input-group",
                    [
                      _c("b-form-input", {
                        attrs: { placeholder: "Buscar...", state: true },
                        model: {
                          value: _vm.buscar,
                          callback: function ($$v) {
                            _vm.buscar = $$v
                          },
                          expression: "buscar",
                        },
                      }),
                      _vm._v(" "),
                      _c(
                        "b-input-group-append",
                        [
                          _c(
                            "b-button",
                            {
                              attrs: { variant: "outline-success" },
                              on: {
                                click: function ($event) {
                                  return _vm.listarPersonal()
                                },
                              },
                            },
                            [_vm._v(" Buscar ")]
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayTable,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c("b-table", {
            attrs: {
              hover: "",
              striped: "",
              responsive: "",
              bordered: "",
              small: "",
              "no-border-collapse": "",
              items: _vm.arrayPersonal,
              fields: _vm.fields,
            },
            scopedSlots: _vm._u([
              {
                key: "cell(p_nombre)",
                fn: function (data) {
                  return [
                    _vm._v(
                      "\n                " +
                        _vm._s(data.item.p_paterno) +
                        " " +
                        _vm._s(data.item.p_materno) +
                        " " +
                        _vm._s(data.item.p_nombre) +
                        "\n            "
                    ),
                  ]
                },
              },
              {
                key: "cell(p_nacimiento)",
                fn: function (data) {
                  return [
                    _vm._v(
                      "\n                " +
                        _vm._s(_vm.$utils.dateFormat(data.item.p_nacimiento)) +
                        "\n            "
                    ),
                  ]
                },
              },
              {
                key: "cell(id_cargo)",
                fn: function (data) {
                  return [
                    _vm._v(
                      "\n                " +
                        _vm._s(_vm.$utils.dateYear(data.item.p_nacimiento)) +
                        "\n            "
                    ),
                  ]
                },
              },
              {
                key: "cell(p_activo)",
                fn: function (data) {
                  return [
                    _c(
                      "b-badge",
                      { attrs: { variant: _vm.estado[1][data.item.p_activo] } },
                      [
                        _vm._v(
                          "\n                    " +
                            _vm._s(_vm.estado[0][data.item.p_activo]) +
                            "\n                "
                        ),
                      ]
                    ),
                  ]
                },
              },
              {
                key: "cell(opcion)",
                fn: function (data) {
                  return [
                    _c(
                      "b-button",
                      {
                        staticClass: "btn-icon rounded-circle text-center",
                        attrs: { variant: "flat-warning", title: "subir doc." },
                        on: {
                          click: function ($event) {
                            return _vm.abrirModalDocumento(data.item)
                          },
                        },
                      },
                      [_c("feather-icon", { attrs: { icon: "FilePlusIcon" } })],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-button",
                      {
                        staticClass: "btn-icon rounded-circle text-center",
                        attrs: { variant: "flat-info", title: "ver doc." },
                        on: {
                          click: function ($event) {
                            return _vm.abrirModalDocPersona(data.item)
                          },
                        },
                      },
                      [_c("feather-icon", { attrs: { icon: "FileTextIcon" } })],
                      1
                    ),
                  ]
                },
              },
            ]),
          }),
          _vm._v(" "),
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { cols: "2" } },
                [
                  _c(
                    "b-form-group",
                    { staticClass: "mb-0" },
                    [
                      _c(
                        "label",
                        { staticClass: "d-inline-block text-sm-left mr-50" },
                        [_vm._v("Por página")]
                      ),
                      _vm._v(" "),
                      _c("b-form-select", {
                        staticClass: "w-50",
                        attrs: { size: "sm", options: _vm.pageOptions },
                        on: {
                          input: function ($event) {
                            return _vm.listarPersonal()
                          },
                        },
                        model: {
                          value: _vm.perPage,
                          callback: function ($$v) {
                            _vm.perPage = $$v
                          },
                          expression: "perPage",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-col", { attrs: { cols: "10" } }, [
                _c(
                  "span",
                  { staticStyle: { float: "right" } },
                  [
                    _c("b-pagination", {
                      staticClass: "my-0",
                      attrs: {
                        "total-rows": _vm.totalRows,
                        "per-page": _vm.perPage,
                        align: "center",
                        size: "sm",
                      },
                      model: {
                        value: _vm.currentPage,
                        callback: function ($$v) {
                          _vm.currentPage = $$v
                        },
                        expression: "currentPage",
                      },
                    }),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: {
            "hide-footer": "",
            centered: "",
            title: "SUBIR DOCUMENTO",
            size: "md",
          },
          model: {
            value: _vm.modalAdjuntarDocumento,
            callback: function ($$v) {
              _vm.modalAdjuntarDocumento = $$v
            },
            expression: "modalAdjuntarDocumento",
          },
        },
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { md: "12" } },
                [
                  _c(
                    "b-form-group",
                    { attrs: { label: "Nombre Documento" } },
                    [
                      _c("b-form-input", {
                        attrs: {
                          rows: "3",
                          placeholder: "Nombre del Documento",
                        },
                        model: {
                          value: _vm.documento,
                          callback: function ($$v) {
                            _vm.documento = $$v
                          },
                          expression: "documento",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "12" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Tipo Documento ")]),
                      _vm._v(" "),
                      _c("b-form-select", {
                        attrs: {
                          options: _vm.arrayTipoDocumento,
                          "value-field": "value",
                        },
                        model: {
                          value: _vm.tipoDocumento,
                          callback: function ($$v) {
                            _vm.tipoDocumento = $$v
                          },
                          expression: "tipoDocumento",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "12" } },
                [
                  _c("b-form-group", { attrs: { label: "Documento" } }, [
                    _c(
                      "form",
                      { attrs: { enctype: "multipart/form-data" } },
                      [
                        _c("b-form-file", {
                          attrs: {
                            accept: ".pdf, .doc, .docx, .xls, .xlsx",
                            placeholder: "Cargar Documento",
                            "browse-text": "Seleccionar",
                          },
                          on: { change: _vm.cargarArchivo },
                          model: {
                            value: _vm.file,
                            callback: function ($$v) {
                              _vm.file = $$v
                            },
                            expression: "file",
                          },
                        }),
                      ],
                      1
                    ),
                  ]),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayStore,
              variant: "success",
              opacity: 0.2,
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-left",
              attrs: { variant: "outline-danger" },
              on: {
                click: function ($event) {
                  _vm.modalAdjuntarDocumento = false
                },
              },
            },
            [_vm._v(" Cancelar ")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-right",
              attrs: { variant: "outline-success" },
              on: {
                click: function ($event) {
                  return _vm.guardarDocumento()
                },
              },
            },
            [_vm._v(" Guardar ")]
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: {
            "hide-footer": "",
            centered: "",
            title: "LISTA DOCUMENTOS",
            size: "md",
          },
          model: {
            value: _vm.modalDocumento,
            callback: function ($$v) {
              _vm.modalDocumento = $$v
            },
            expression: "modalDocumento",
          },
        },
        [
          _c("span", [_c("b", [_vm._v(" " + _vm._s(_vm.persona) + " ")])]),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c("b-table", {
            attrs: {
              hover: "",
              striped: "",
              responsive: "",
              bordered: "",
              small: "",
              "no-border-collapse": "",
              items: _vm.arrayDocPersona,
              fields: _vm.fields2,
            },
            scopedSlots: _vm._u([
              {
                key: "cell(opcion)",
                fn: function (data) {
                  return [
                    _c(
                      "b-button",
                      {
                        staticClass: "btn-icon rounded-circle text-center",
                        attrs: { variant: "flat-success", title: "descargar" },
                        on: {
                          click: function ($event) {
                            return _vm.descargarDoc(data.item)
                          },
                        },
                      },
                      [_c("feather-icon", { attrs: { icon: "DownloadIcon" } })],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-button",
                      {
                        staticClass: "btn-icon rounded-circle text-center",
                        attrs: { variant: "flat-danger", title: "Eliminar" },
                        on: {
                          click: function ($event) {
                            return _vm.abrirModalAnulacion(data.item)
                          },
                        },
                      },
                      [_c("feather-icon", { attrs: { icon: "XCircleIcon" } })],
                      1
                    ),
                  ]
                },
              },
            ]),
          }),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: {
            "hide-footer": "",
            centered: "",
            title: "ANULAR DOCUMENTO",
            size: "md",
          },
          model: {
            value: _vm.modalAnulacion,
            callback: function ($$v) {
              _vm.modalAnulacion = $$v
            },
            expression: "modalAnulacion",
          },
        },
        [
          _c(
            "b-button",
            {
              staticClass: "float-left",
              attrs: { variant: "outline-danger" },
              on: {
                click: function ($event) {
                  _vm.modalAnulacion = false
                },
              },
            },
            [_vm._v(" Cancelar ")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-right",
              attrs: { variant: "outline-success" },
              on: {
                click: function ($event) {
                  return _vm.anularDOC()
                },
              },
            },
            [_vm._v(" Aceptar ")]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/GestionDocumental/DocumentoPersonal.vue":
/*!************************************************************************!*\
  !*** ./resources/js/src/views/GestionDocumental/DocumentoPersonal.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DocumentoPersonal_vue_vue_type_template_id_3eff92fa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DocumentoPersonal.vue?vue&type=template&id=3eff92fa& */ "./resources/js/src/views/GestionDocumental/DocumentoPersonal.vue?vue&type=template&id=3eff92fa&");
/* harmony import */ var _DocumentoPersonal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DocumentoPersonal.vue?vue&type=script&lang=js& */ "./resources/js/src/views/GestionDocumental/DocumentoPersonal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _DocumentoPersonal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _DocumentoPersonal_vue_vue_type_template_id_3eff92fa___WEBPACK_IMPORTED_MODULE_0__["render"],
  _DocumentoPersonal_vue_vue_type_template_id_3eff92fa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/GestionDocumental/DocumentoPersonal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/GestionDocumental/DocumentoPersonal.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/src/views/GestionDocumental/DocumentoPersonal.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DocumentoPersonal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./DocumentoPersonal.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/GestionDocumental/DocumentoPersonal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DocumentoPersonal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/GestionDocumental/DocumentoPersonal.vue?vue&type=template&id=3eff92fa&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/GestionDocumental/DocumentoPersonal.vue?vue&type=template&id=3eff92fa& ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DocumentoPersonal_vue_vue_type_template_id_3eff92fa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./DocumentoPersonal.vue?vue&type=template&id=3eff92fa& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/GestionDocumental/DocumentoPersonal.vue?vue&type=template&id=3eff92fa&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DocumentoPersonal_vue_vue_type_template_id_3eff92fa___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DocumentoPersonal_vue_vue_type_template_id_3eff92fa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);