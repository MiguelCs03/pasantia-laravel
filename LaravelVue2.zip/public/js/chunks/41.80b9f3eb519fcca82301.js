(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[41],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/Proveedor.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Farmacia/Proveedor.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      // paginación
      pageOptions: [50, 100, 200, 500],
      currentPage: 1,
      totalRows: 1,
      perPage: 50,
      buscar: '',
      overlayTable: false,
      arrayProveedor: [],
      fields: [{
        key: 'pro_razon_social',
        label: 'nombre fabricante'
      }, {
        key: 'pro_celular',
        label: 'celular'
      }, {
        key: 'pro_correo',
        label: 'correo'
      }, {
        key: 'pro_activo',
        label: 'estado',
        "class": 'text-center text-nowrap'
      }, {
        key: 'opcion',
        label: 'opción',
        "class": 'text-center text-nowrap'
      }],
      estado: [{
        0: 'INACTIVO',
        1: 'ACTIVO'
      }, {
        0: 'light-danger',
        1: 'light-success'
      }],
      title: '',
      objProveedor: {},
      modalStorage: false,
      overlayStorage: false
    };
  },
  mounted: function mounted() {
    this.listarProveedor();
  },
  methods: {
    abrirModal: function abrirModal(item) {
      if (item != null) {
        this.title = 'EDITAR PROVEEDOR';
        this.objProveedor = {
          id: item.id_proveedor,
          correo: item.pro_correo,
          nombre: item.pro_razon_social,
          celular: item.pro_celular
        };
      } else {
        this.title = 'NUEVO PROVEEDOR';
        this.objProveedor = {
          id: 0
        };
      }

      this.modalStorage = true;
    },
    listarProveedor: function listarProveedor() {
      var _this = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarProveedor?perPage=' + this.perPage + '&page=' + this.currentPage + '&buscar=' + this.buscar).then(function (res) {
        _this.arrayProveedor = res.data.data;
        _this.totalRows = res.data.total;
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this.overlayTable = false;
      });
    },
    guardarProveedor: function guardarProveedor() {
      var _this2 = this;

      this.overlayStorage = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/guardarProveedor', {
        'id': this.objProveedor.id,
        'correo': this.objProveedor.correo,
        'nombre': this.objProveedor.nombre,
        'celular': this.objProveedor.celular
      }).then(function (res) {
        _this2.listarProveedor();

        _this2.modalStorage = false;

        _this2.pop_up('Éxito', 'Guardado Correctamente', 'success');
      })["catch"](function (err) {
        console.log(err);
        if (err.response.status == 422) _this2.pop_up('Error', 'Debe llenar los campos obligatorios', 'error');else _this2.pop_up('Error', 'no se puedo Guardar', 'error');
      })["finally"](function () {
        _this2.overlayStorage = false;
      });
    },
    cambiarEstadoProveedor: function cambiarEstadoProveedor(item) {
      var _this3 = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/cambiarEstadoProveedor', {
        'id': item.id_proveedor,
        'estado': item.pro_activo == 1 ? 0 : 1
      }).then(function (res) {
        _this3.listarProveedor();

        _this3.pop_up('Éxito', 'Guardado Correctamente', 'success');
      })["catch"](function (err) {
        console.log(err);
        _this3.overlayTable = false;
        if (err.response.status == 422) _this3.pop_up('Error', 'Debe llenar los campos obligatorios', 'error');else _this3.pop_up('Error', 'no se puedo Guardar', 'error');
      });
    },
    pop_up: function pop_up(title, text, icon) {
      this.$swal({
        title: title,
        text: text,
        icon: icon,
        showConfirmButton: false,
        timer: 2000,
        customClass: {
          confirmButton: 'btn btn-primary'
        },
        buttonsStyling: false
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/Proveedor.vue?vue&type=template&id=70ec7689&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Farmacia/Proveedor.vue?vue&type=template&id=70ec7689& ***!
  \********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-card",
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-button",
                    {
                      attrs: { variant: "outline-success" },
                      on: {
                        click: function ($event) {
                          return _vm.abrirModal(null)
                        },
                      },
                    },
                    [_vm._v(" Nuevo Proveedor ")]
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-input-group",
                    [
                      _c("b-form-input", {
                        attrs: { placeholder: "Buscar...", state: true },
                        model: {
                          value: _vm.buscar,
                          callback: function ($$v) {
                            _vm.buscar = $$v
                          },
                          expression: "buscar",
                        },
                      }),
                      _vm._v(" "),
                      _c(
                        "b-input-group-append",
                        [
                          _c(
                            "b-button",
                            {
                              attrs: { variant: "outline-success" },
                              on: {
                                click: function ($event) {
                                  return _vm.listarProveedor()
                                },
                              },
                            },
                            [_vm._v(" Buscar ")]
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayTable,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c("b-table", {
            attrs: {
              hover: "",
              striped: "",
              responsive: "",
              bordered: "",
              small: "",
              "no-border-collapse": "",
              items: _vm.arrayProveedor,
              fields: _vm.fields,
            },
            scopedSlots: _vm._u([
              {
                key: "cell(pro_activo)",
                fn: function (data) {
                  return [
                    _c(
                      "b-badge",
                      {
                        attrs: { variant: _vm.estado[1][data.item.pro_activo] },
                      },
                      [
                        _vm._v(
                          "\n                    " +
                            _vm._s(_vm.estado[0][data.item.pro_activo]) +
                            "\n                "
                        ),
                      ]
                    ),
                  ]
                },
              },
              {
                key: "cell(opcion)",
                fn: function (data) {
                  return [
                    _c(
                      "b-button",
                      {
                        staticClass: "btn-icon rounded-circle text-center",
                        attrs: {
                          variant: data.item.pro_activo
                            ? "flat-danger"
                            : "flat-success",
                          title: data.item.pro_activo
                            ? "desactivar"
                            : "activar",
                        },
                        on: {
                          click: function ($event) {
                            return _vm.cambiarEstadoProveedor(data.item)
                          },
                        },
                      },
                      [
                        _c("feather-icon", {
                          attrs: {
                            icon: data.item.pro_activo
                              ? "LockIcon"
                              : "UnlockIcon",
                          },
                        }),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-button",
                      {
                        staticClass: "btn-icon rounded-circle text-center",
                        attrs: { variant: "flat-info", title: "editar" },
                        on: {
                          click: function ($event) {
                            return _vm.abrirModal(data.item)
                          },
                        },
                      },
                      [_c("feather-icon", { attrs: { icon: "EditIcon" } })],
                      1
                    ),
                  ]
                },
              },
            ]),
          }),
          _vm._v(" "),
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { cols: "2" } },
                [
                  _c(
                    "b-form-group",
                    { staticClass: "mb-0" },
                    [
                      _c(
                        "label",
                        { staticClass: "d-inline-block text-sm-left mr-50" },
                        [_vm._v("Por página")]
                      ),
                      _vm._v(" "),
                      _c("b-form-select", {
                        staticClass: "w-50",
                        attrs: { size: "sm", options: _vm.pageOptions },
                        on: {
                          input: function ($event) {
                            return _vm.listarProveedor()
                          },
                        },
                        model: {
                          value: _vm.perPage,
                          callback: function ($$v) {
                            _vm.perPage = $$v
                          },
                          expression: "perPage",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-col", { attrs: { cols: "10" } }, [
                _c(
                  "span",
                  { staticStyle: { float: "right" } },
                  [
                    _c("b-pagination", {
                      staticClass: "my-0",
                      attrs: {
                        "total-rows": _vm.totalRows,
                        "per-page": _vm.perPage,
                        align: "center",
                        size: "sm",
                      },
                      model: {
                        value: _vm.currentPage,
                        callback: function ($$v) {
                          _vm.currentPage = $$v
                        },
                        expression: "currentPage",
                      },
                    }),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: { "hide-footer": "", centered: "", title: _vm.title },
          model: {
            value: _vm.modalStorage,
            callback: function ($$v) {
              _vm.modalStorage = $$v
            },
            expression: "modalStorage",
          },
        },
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { md: "12" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Nombre ")]),
                      _vm._v(" "),
                      _c("b-form-input", {
                        attrs: {
                          placeholder: "Nombre",
                          state: _vm.objProveedor.nombre != null,
                        },
                        model: {
                          value: _vm.objProveedor.nombre,
                          callback: function ($$v) {
                            _vm.$set(_vm.objProveedor, "nombre", $$v)
                          },
                          expression: "objProveedor.nombre",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Celular ")]),
                      _vm._v(" "),
                      _c("b-form-input", {
                        attrs: {
                          type: "number",
                          placeholder: "Celular",
                          state: _vm.objProveedor.celular != null,
                        },
                        model: {
                          value: _vm.objProveedor.celular,
                          callback: function ($$v) {
                            _vm.$set(_vm.objProveedor, "celular", $$v)
                          },
                          expression: "objProveedor.celular",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Correo ")]),
                      _vm._v(" "),
                      _c("b-form-input", {
                        attrs: {
                          placeholder: "Correo",
                          state: _vm.objProveedor.correo != null,
                        },
                        model: {
                          value: _vm.objProveedor.correo,
                          callback: function ($$v) {
                            _vm.$set(_vm.objProveedor, "correo", $$v)
                          },
                          expression: "objProveedor.correo",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayStorage,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-left",
              attrs: { variant: "outline-danger" },
              on: {
                click: function ($event) {
                  _vm.modalStorage = false
                },
              },
            },
            [_vm._v(" Cancelar ")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-right",
              attrs: { variant: "outline-success" },
              on: {
                click: function ($event) {
                  return _vm.guardarProveedor()
                },
              },
            },
            [_vm._v(" Guardar ")]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/Farmacia/Proveedor.vue":
/*!*******************************************************!*\
  !*** ./resources/js/src/views/Farmacia/Proveedor.vue ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Proveedor_vue_vue_type_template_id_70ec7689___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Proveedor.vue?vue&type=template&id=70ec7689& */ "./resources/js/src/views/Farmacia/Proveedor.vue?vue&type=template&id=70ec7689&");
/* harmony import */ var _Proveedor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Proveedor.vue?vue&type=script&lang=js& */ "./resources/js/src/views/Farmacia/Proveedor.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Proveedor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Proveedor_vue_vue_type_template_id_70ec7689___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Proveedor_vue_vue_type_template_id_70ec7689___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/Farmacia/Proveedor.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/Farmacia/Proveedor.vue?vue&type=script&lang=js&":
/*!********************************************************************************!*\
  !*** ./resources/js/src/views/Farmacia/Proveedor.vue?vue&type=script&lang=js& ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Proveedor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Proveedor.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/Proveedor.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Proveedor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/Farmacia/Proveedor.vue?vue&type=template&id=70ec7689&":
/*!**************************************************************************************!*\
  !*** ./resources/js/src/views/Farmacia/Proveedor.vue?vue&type=template&id=70ec7689& ***!
  \**************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Proveedor_vue_vue_type_template_id_70ec7689___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Proveedor.vue?vue&type=template&id=70ec7689& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/Proveedor.vue?vue&type=template&id=70ec7689&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Proveedor_vue_vue_type_template_id_70ec7689___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Proveedor_vue_vue_type_template_id_70ec7689___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);