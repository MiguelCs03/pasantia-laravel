(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[38],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/ListaCM.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Farmacia/ListaCM.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/web.url.js */ "./node_modules/core-js/modules/web.url.js");
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_4__);





//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      // paginación
      pageOptions: [50, 100, 200, 500],
      currentPage: 1,
      totalRows: 1,
      perPage: 50,
      buscar: '',
      id_consulta_medica: null,
      modalAnulacion: false,
      overlayTable: false,
      arrayExamen: [],
      fields: [{
        key: 'persona',
        label: 'persona'
      }, {
        key: 'medico',
        label: 'médico'
      }, {
        key: 'cm_diagnostico',
        label: 'diagnóstico'
      }, {
        key: 'cm_examen_fisico',
        label: 'exámen físico'
      }, {
        key: 'cm_activo',
        label: 'estado',
        "class": 'text-center'
      }, {
        key: 'opcion',
        label: 'opción',
        "class": 'text-center text-nowrap'
      }],
      estado: [{
        0: 'INACTIVO',
        1: 'ACTIVO'
      }, {
        0: 'light-danger',
        1: 'light-success'
      }]
    };
  },
  mounted: function mounted() {
    this.listarExamen();
  },
  methods: {
    listarExamen: function listarExamen() {
      var _this = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarConsultaMedica?perPage=' + this.perPage + '&page=' + this.currentPage + '&buscar=' + this.buscar).then(function (res) {
        _this.arrayExamen = [];
        _this.arrayExamen = res.data.data;
        _this.totalRows = res.data.total;
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this.overlayTable = false;
      });
    },
    editar: function editar(item) {
      this.$router.push({
        path: '/consulta_medica_editar_v2',
        query: {
          id_consulta_medica: item.id_consulta_medica
        }
      });
    },
    abrirModalAnulacion: function abrirModalAnulacion(item) {
      this.id_consulta_medica = item.id_consulta_medica;
      this.modalAnulacion = true;
    },
    anular: function anular() {
      var _this2 = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/anularConsultaMedica', {
        id_consulta_medica: this.id_consulta_medica
      }).then(function () {
        _this2.listarExamen();

        _this2.modalAnulacion = false;

        _this2.pop_up('Anulado', 'La consulta medica ha sido anulada exitosamente.', 'success');
      })["catch"](function (err) {
        console.error(err);

        _this2.pop_up('Error', 'Ocurrió un error al intentar anular la consulta.', 'error');
      })["finally"](function () {
        _this2.overlayTable = false;
      });
    },
    imprimirExamenClinico: function imprimirExamenClinico(item) {
      var _this3 = this;

      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/imprimirConsultaMedica?id_consulta_medica=' + item.id_consulta_medica, {
        responseType: 'blob'
      }).then(function (res) {
        var url = window.URL.createObjectURL(new Blob([res.data], {
          type: 'application/pdf'
        }));
        var link = document.createElement('a');
        link.href = url;
        link.target = '_blank';
        link.click();
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this3.overlayTable = false;
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/ListaCM.vue?vue&type=template&id=02d06c18&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Farmacia/ListaCM.vue?vue&type=template&id=02d06c18& ***!
  \******************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-card",
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-button",
                    {
                      attrs: { variant: "outline-success" },
                      on: {
                        click: function ($event) {
                          return _vm.$router.push("/consulta_medica_v2")
                        },
                      },
                    },
                    [_vm._v(" Nueva Consulta ")]
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-input-group",
                    [
                      _c("b-form-input", {
                        attrs: { placeholder: "Buscar...", state: true },
                        model: {
                          value: _vm.buscar,
                          callback: function ($$v) {
                            _vm.buscar = $$v
                          },
                          expression: "buscar",
                        },
                      }),
                      _vm._v(" "),
                      _c(
                        "b-input-group-append",
                        [
                          _c(
                            "b-button",
                            {
                              attrs: { variant: "outline-success" },
                              on: {
                                click: function ($event) {
                                  return _vm.listarExamen()
                                },
                              },
                            },
                            [_vm._v(" Buscar ")]
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayTable,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c("b-table", {
            attrs: {
              hover: "",
              striped: "",
              responsive: "",
              bordered: "",
              small: "",
              "no-border-collapse": "",
              items: _vm.arrayExamen,
              fields: _vm.fields,
            },
            scopedSlots: _vm._u([
              {
                key: "cell(cm_activo)",
                fn: function (data) {
                  return [
                    _c(
                      "b-badge",
                      {
                        attrs: { variant: _vm.estado[1][data.item.cm_activo] },
                      },
                      [
                        _vm._v(
                          "\n                    " +
                            _vm._s(_vm.estado[0][data.item.cm_activo]) +
                            "\n                "
                        ),
                      ]
                    ),
                  ]
                },
              },
              {
                key: "cell(opcion)",
                fn: function (data) {
                  return [
                    _c("feather-icon", {
                      staticClass: "icon-action text-primary mr-2",
                      class: { disabled: data.item.cm_activo === 0 },
                      attrs: { icon: "EditIcon" },
                      on: {
                        click: function ($event) {
                          data.item.cm_activo ? _vm.editar(data.item) : null
                        },
                      },
                    }),
                    _vm._v(" "),
                    _c("feather-icon", {
                      staticClass: "icon-action text-danger mr-2",
                      class: { disabled: data.item.cm_activo === 0 },
                      attrs: { icon: "XCircleIcon" },
                      on: {
                        click: function ($event) {
                          data.item.cm_activo
                            ? _vm.abrirModalAnulacion(data.item)
                            : null
                        },
                      },
                    }),
                    _vm._v(" "),
                    _c("feather-icon", {
                      staticClass: "icon-action text-secondary",
                      class: { disabled: data.item.cm_activo === 0 },
                      attrs: { icon: "PrinterIcon" },
                      on: {
                        click: function ($event) {
                          data.item.cm_activo
                            ? _vm.imprimirExamenClinico(data.item)
                            : null
                        },
                      },
                    }),
                  ]
                },
              },
            ]),
          }),
          _vm._v(" "),
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { cols: "2" } },
                [
                  _c(
                    "b-form-group",
                    { staticClass: "mb-0" },
                    [
                      _c(
                        "label",
                        { staticClass: "d-inline-block text-sm-left mr-50" },
                        [_vm._v("Por página")]
                      ),
                      _vm._v(" "),
                      _c("b-form-select", {
                        staticClass: "w-50",
                        attrs: { size: "sm", options: _vm.pageOptions },
                        on: {
                          input: function ($event) {
                            return _vm.listarExamen()
                          },
                        },
                        model: {
                          value: _vm.perPage,
                          callback: function ($$v) {
                            _vm.perPage = $$v
                          },
                          expression: "perPage",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-col", { attrs: { cols: "10" } }, [
                _c(
                  "span",
                  { staticStyle: { float: "right" } },
                  [
                    _c("b-pagination", {
                      staticClass: "my-0",
                      attrs: {
                        "total-rows": _vm.totalRows,
                        "per-page": _vm.perPage,
                        align: "center",
                        size: "sm",
                      },
                      model: {
                        value: _vm.currentPage,
                        callback: function ($$v) {
                          _vm.currentPage = $$v
                        },
                        expression: "currentPage",
                      },
                    }),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: {
            "hide-footer": "",
            centered: "",
            title: "ANULAR CONSULTA MEDICA",
            size: "md",
          },
          model: {
            value: _vm.modalAnulacion,
            callback: function ($$v) {
              _vm.modalAnulacion = $$v
            },
            expression: "modalAnulacion",
          },
        },
        [
          _c(
            "b-button",
            {
              staticClass: "float-left",
              attrs: { variant: "outline-danger" },
              on: {
                click: function ($event) {
                  _vm.modalAnulacion = false
                },
              },
            },
            [_vm._v(" Cancelar ")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-right",
              attrs: { variant: "outline-success" },
              on: {
                click: function ($event) {
                  return _vm.anular()
                },
              },
            },
            [_vm._v(" Aceptar ")]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/Farmacia/ListaCM.vue":
/*!*****************************************************!*\
  !*** ./resources/js/src/views/Farmacia/ListaCM.vue ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ListaCM_vue_vue_type_template_id_02d06c18___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ListaCM.vue?vue&type=template&id=02d06c18& */ "./resources/js/src/views/Farmacia/ListaCM.vue?vue&type=template&id=02d06c18&");
/* harmony import */ var _ListaCM_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ListaCM.vue?vue&type=script&lang=js& */ "./resources/js/src/views/Farmacia/ListaCM.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ListaCM_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ListaCM_vue_vue_type_template_id_02d06c18___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ListaCM_vue_vue_type_template_id_02d06c18___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/Farmacia/ListaCM.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/Farmacia/ListaCM.vue?vue&type=script&lang=js&":
/*!******************************************************************************!*\
  !*** ./resources/js/src/views/Farmacia/ListaCM.vue?vue&type=script&lang=js& ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaCM_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./ListaCM.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/ListaCM.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaCM_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/Farmacia/ListaCM.vue?vue&type=template&id=02d06c18&":
/*!************************************************************************************!*\
  !*** ./resources/js/src/views/Farmacia/ListaCM.vue?vue&type=template&id=02d06c18& ***!
  \************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaCM_vue_vue_type_template_id_02d06c18___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./ListaCM.vue?vue&type=template&id=02d06c18& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/ListaCM.vue?vue&type=template&id=02d06c18&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaCM_vue_vue_type_template_id_02d06c18___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaCM_vue_vue_type_template_id_02d06c18___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);