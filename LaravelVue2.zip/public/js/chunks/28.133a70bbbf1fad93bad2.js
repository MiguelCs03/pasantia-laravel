(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[28],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Inventario/TomaInventario.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Inventario/TomaInventario.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/web.url.js */ "./node_modules/core-js/modules/web.url.js");
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_11__);












//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      // paginación
      pageOptions: [50, 100, 200, 500],
      currentPage: 1,
      totalRows: 1,
      perPage: 50,
      buscar: '',
      overlayAnulacion: false,
      overlayTable: false,
      fields: [{
        key: 'inicio',
        label: 'fecha inicio'
      }, {
        key: 'fin',
        label: 'fecha fin'
      }, {
        key: 'nro_inv',
        label: 'nro Inventario'
      }, {
        key: 'relevado_por',
        label: 'relevado por'
      }, {
        key: 'validado_por',
        label: 'validado por'
      }, {
        key: 'aprobado_por',
        label: 'aprobado por',
        "class": 'text-center text-nowrap'
      }, {
        key: 'nota',
        label: 'notas',
        "class": 'text-center text-nowrap'
      }, {
        key: 'estado',
        label: 'estado',
        "class": 'text-center text-nowrap'
      }, {
        key: 'opcion',
        label: 'opcion',
        "class": 'text-center text-nowrap'
      }],
      estado: [{
        0: 'INACTIVO',
        1: 'ACTIVO'
      }, {
        0: 'light-danger',
        1: 'light-success'
      }],
      fields2: [{
        key: 'id_medicamento',
        label: '#'
      }, {
        key: 'med_nombre',
        label: 'medicamento'
      }, {
        key: 'seleccion',
        label: 'Seleccion',
        sortable: false
      }],
      arrayTomaInventario: [],
      objTomaInventario: {
        id_almacen: null,
        relevado_por: null,
        validado_por: null,
        aprobado_por: null,
        anualado_por: null,
        nota: '',
        memo_anular: ''
      },
      title: '',
      arrayPersonas: [],
      arrayUsuarios: [],
      arrayAlmacen: [],
      arrayMedicamentos: [],
      arrayCargos: [],
      modalNuevaTomaInventario: false,
      overlayTomaInventario: false,
      modalAnulacion: false,
      id_tm: null,
      estadoActual: null,
      seleccionarTodos: false
    };
  },
  mounted: function mounted() {
    this.listarTomaInventario();
    this.listarSelectPersona();
    this.listarSelectUsuario();
    this.listarSelectAlmacen();
  },
  methods: {
    toggleSeleccionarTodos: function toggleSeleccionarTodos() {
      var _this = this;

      this.arrayMedicamentos.forEach(function (medicamento) {
        medicamento.selected = _this.seleccionarTodos;
      });
    },
    listarTomaInventario: function listarTomaInventario() {
      var _this2 = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/ListarTomaInventarioSelect?buscar=' + this.buscar).then(function (res) {
        _this2.arrayTomaInventario = res.data.map(function (tomaInventario) {
          return {
            id_tm: tomaInventario.id_tm,
            inicio: tomaInventario.inicio,
            fin: tomaInventario.fin,
            nro_inv: tomaInventario.nro_inv,
            relevado_por: tomaInventario.relevado_por,
            validado_por: tomaInventario.validado,
            aprobado_por: tomaInventario.aprobado,
            nota: tomaInventario.nota,
            estado: tomaInventario.estado
          };
        });
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this2.overlayTable = false;
      });
    },
    listarSelectPersona: function listarSelectPersona() {
      var _this3 = this;

      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarSelectPersona').then(function (res) {
        _this3.arrayPersonas = res.data.map(function (persona) {
          return {
            value: persona.id_persona,
            text: "".concat(persona.nombre)
          };
        });
        console.log(_this3.arrayUsuarios);
      })["catch"](function (err) {
        console.error(err);
      });
    },
    listarSelectUsuario: function listarSelectUsuario() {
      var _this4 = this;

      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarUsuarios').then(function (res) {
        _this4.arrayUsuarios = res.data.map(function (persona) {
          return {
            value: persona.id,
            text: "".concat(persona.name)
          };
        });
      })["catch"](function (err) {});
    },
    listarSelectAlmacen: function listarSelectAlmacen() {
      var _this5 = this;

      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarSelectAlamacen').then(function (res) {
        _this5.arrayAlmacen = res.data.map(function (almacen) {
          return {
            value: almacen.id_almacen,
            text: "".concat(almacen.a_almacen)
          };
        });
      })["catch"](function (err) {
        console.error(err);
      });
    },
    listarMedicamento: function listarMedicamento() {
      var _this6 = this;

      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarMedicamento?perPage=' + this.perPage + '&page=' + this.currentPage + '&buscar=' + this.buscar).then(function (res) {
        _this6.arrayMedicamentos = res.data.data;
        _this6.totalRows = res.data.total;
      })["catch"](function (err) {
        console.log(err);
      });
    },
    isFormValid: function isFormValid() {
      var combosValidos = this.objTomaInventario.relevado_por != null && this.objTomaInventario.validado_por != null && this.objTomaInventario.id_almacen != null;
      var ItemSeleccionado = this.arrayMedicamentos.some(function (medicamento) {
        return medicamento.selected;
      });
      return combosValidos && ItemSeleccionado;
    },
    crearTomaInventario: function crearTomaInventario() {
      var _this7 = this;

      this.overlayStorage = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      var fechaActual = new Date().toISOString().slice(0, 19).replace('T', ' ');
      this.axios.post('/guardarTomaInventario', {
        'id_almacen': this.objTomaInventario.id_almacen,
        'inicio': fechaActual,
        'fin': null,
        'aprobacion': '',
        'anulado': null,
        'relevado_por': this.objTomaInventario.relevado_por,
        'validado_por': this.objTomaInventario.validado_por,
        'aprobado_por': '',
        'anulado_por': '',
        'estado': 'P',
        'nota': this.objTomaInventario.nota,
        'memo_anular': '',
        'activo': 1,
        'creadopor': localStorage.getItem('id'),
        'creadoel': fechaActual,
        'modificadoel': ''
      }).then(function (res) {
        var nuevoId_tm = res.data.id_tm;

        _this7.listarTomaInventario();

        _this7.modalStorage = false;

        _this7.crearInventarioFisico(nuevoId_tm);
      })["catch"](function (err) {
        console.log(err);

        if (err.response.status == 422) {
          _this7.pop_up('Error', 'Debe llenar los campos obligatorios', 'error');
        } else {
          _this7.pop_up('Error', 'No se pudo guardar', 'error');
        }
      })["finally"](function () {
        _this7.overlayStorage = false;
        _this7.modalNuevaTomaInventario = false;
      });
    },
    crearInventarioFisico: function crearInventarioFisico(id_tm) {
      var _this8 = this;

      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      var fechaActual = new Date().toISOString().slice(0, 19).replace('T', ' ');
      var medicamentos = this.arrayMedicamentos.filter(function (medicamento) {
        return medicamento.selected;
      });

      if (medicamentos.length === 0) {
        this.pop_up('Error', 'Debe seleccionar al menos un medicamento', 'error');
        return;
      }

      axios.post('/guardarInventarioFisico', {
        'id_tm': id_tm,
        'medicamentos': medicamentos,
        'activo': 1,
        'creadopor': localStorage.getItem('id'),
        'creadoel': fechaActual
      }).then(function (res) {
        _this8.pop_up('Éxito', 'Guardado Correctamente', 'success');
      })["catch"](function (err) {
        console.log(err);

        _this8.pop_up('Error', 'Debe llenar los campos obligatorios', 'error');
      });
    },
    abrirModalTomaInventario: function abrirModalTomaInventario(item) {
      this.title = 'NUEVA TOMA DE INVENTARIO';
      this.modalNuevaTomaInventario = true;
    },
    abrirModalAnulacion: function abrirModalAnulacion(item) {
      this.id_tm = item.id_tm;
      this.estadoActual = item.estado;
      this.modalAnulacion = true;
    },
    anularTomaInventario: function anularTomaInventario() {
      var _this9 = this;

      if (this.estadoActual !== 'P' && this.estadoActual !== 'R') {
        this.pop_up('Error', 'Solo se puede anular si el estado es en Proceso o Revision');
        return;
      }

      var fechaActual = new Date().toISOString().slice(0, 19).replace('T', ' ');
      this.overlayAnulacion = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/anularTomaInventario', {
        'id_tm': this.id_tm,
        'fin': fechaActual,
        'anulado': fechaActual,
        'estado': 'A',
        'memo_anular': this.objTomaInventario.memo_anular,
        'anulado_por': localStorage.getItem('id')
      }).then(function (res) {
        _this9.listarTomaInventario();

        _this9.pop_up('Éxito', 'Anulado Correctamente', 'success');

        _this9.modalAnulacion = false;
        _this9.overlayAnulacion = false;
      })["catch"](function (err) {
        console.log(err);
        _this9.overlayAnulacion = false;

        _this9.pop_up('Error', 'No se puede Anular', 'error');
      });
    },
    descargarPDF: function descargarPDF(item) {
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      axios.get('/PDFTomaInventarioS?id_tm=' + item.id_tm, {
        responseType: 'blob'
      }).then(function (res) {
        var url = window.URL.createObjectURL(new Blob([res.data], {
          type: 'application/pdf'
        }));
        var link = document.createElement('a');
        link.href = url;
        link.target = '_blank';
        link.click();
      })["catch"](function (err) {
        console.log(err);
      });
    },
    pop_up: function pop_up(title, text, icon) {
      this.$swal({
        title: title,
        text: text,
        icon: icon,
        showConfirmButton: false,
        timer: 2000,
        customClass: {
          confirmButton: 'btn btn-primary'
        },
        buttonsStyling: false
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es.string.replace.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es.string.replace.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var fixRegExpWellKnownSymbolLogic = __webpack_require__(/*! ../internals/fix-regexp-well-known-symbol-logic */ "./node_modules/core-js/internals/fix-regexp-well-known-symbol-logic.js");
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
var toObject = __webpack_require__(/*! ../internals/to-object */ "./node_modules/core-js/internals/to-object.js");
var toLength = __webpack_require__(/*! ../internals/to-length */ "./node_modules/core-js/internals/to-length.js");
var toInteger = __webpack_require__(/*! ../internals/to-integer */ "./node_modules/core-js/internals/to-integer.js");
var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/core-js/internals/require-object-coercible.js");
var advanceStringIndex = __webpack_require__(/*! ../internals/advance-string-index */ "./node_modules/core-js/internals/advance-string-index.js");
var regExpExec = __webpack_require__(/*! ../internals/regexp-exec-abstract */ "./node_modules/core-js/internals/regexp-exec-abstract.js");

var max = Math.max;
var min = Math.min;
var floor = Math.floor;
var SUBSTITUTION_SYMBOLS = /\$([$&'`]|\d\d?|<[^>]*>)/g;
var SUBSTITUTION_SYMBOLS_NO_NAMED = /\$([$&'`]|\d\d?)/g;

var maybeToString = function (it) {
  return it === undefined ? it : String(it);
};

// @@replace logic
fixRegExpWellKnownSymbolLogic('replace', 2, function (REPLACE, nativeReplace, maybeCallNative, reason) {
  var REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE = reason.REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE;
  var REPLACE_KEEPS_$0 = reason.REPLACE_KEEPS_$0;
  var UNSAFE_SUBSTITUTE = REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE ? '$' : '$0';

  return [
    // `String.prototype.replace` method
    // https://tc39.github.io/ecma262/#sec-string.prototype.replace
    function replace(searchValue, replaceValue) {
      var O = requireObjectCoercible(this);
      var replacer = searchValue == undefined ? undefined : searchValue[REPLACE];
      return replacer !== undefined
        ? replacer.call(searchValue, O, replaceValue)
        : nativeReplace.call(String(O), searchValue, replaceValue);
    },
    // `RegExp.prototype[@@replace]` method
    // https://tc39.github.io/ecma262/#sec-regexp.prototype-@@replace
    function (regexp, replaceValue) {
      if (
        (!REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE && REPLACE_KEEPS_$0) ||
        (typeof replaceValue === 'string' && replaceValue.indexOf(UNSAFE_SUBSTITUTE) === -1)
      ) {
        var res = maybeCallNative(nativeReplace, regexp, this, replaceValue);
        if (res.done) return res.value;
      }

      var rx = anObject(regexp);
      var S = String(this);

      var functionalReplace = typeof replaceValue === 'function';
      if (!functionalReplace) replaceValue = String(replaceValue);

      var global = rx.global;
      if (global) {
        var fullUnicode = rx.unicode;
        rx.lastIndex = 0;
      }
      var results = [];
      while (true) {
        var result = regExpExec(rx, S);
        if (result === null) break;

        results.push(result);
        if (!global) break;

        var matchStr = String(result[0]);
        if (matchStr === '') rx.lastIndex = advanceStringIndex(S, toLength(rx.lastIndex), fullUnicode);
      }

      var accumulatedResult = '';
      var nextSourcePosition = 0;
      for (var i = 0; i < results.length; i++) {
        result = results[i];

        var matched = String(result[0]);
        var position = max(min(toInteger(result.index), S.length), 0);
        var captures = [];
        // NOTE: This is equivalent to
        //   captures = result.slice(1).map(maybeToString)
        // but for some reason `nativeSlice.call(result, 1, result.length)` (called in
        // the slice polyfill when slicing native arrays) "doesn't work" in safari 9 and
        // causes a crash (https://pastebin.com/N21QzeQA) when trying to debug it.
        for (var j = 1; j < result.length; j++) captures.push(maybeToString(result[j]));
        var namedCaptures = result.groups;
        if (functionalReplace) {
          var replacerArgs = [matched].concat(captures, position, S);
          if (namedCaptures !== undefined) replacerArgs.push(namedCaptures);
          var replacement = String(replaceValue.apply(undefined, replacerArgs));
        } else {
          replacement = getSubstitution(matched, S, position, captures, namedCaptures, replaceValue);
        }
        if (position >= nextSourcePosition) {
          accumulatedResult += S.slice(nextSourcePosition, position) + replacement;
          nextSourcePosition = position + matched.length;
        }
      }
      return accumulatedResult + S.slice(nextSourcePosition);
    }
  ];

  // https://tc39.github.io/ecma262/#sec-getsubstitution
  function getSubstitution(matched, str, position, captures, namedCaptures, replacement) {
    var tailPos = position + matched.length;
    var m = captures.length;
    var symbols = SUBSTITUTION_SYMBOLS_NO_NAMED;
    if (namedCaptures !== undefined) {
      namedCaptures = toObject(namedCaptures);
      symbols = SUBSTITUTION_SYMBOLS;
    }
    return nativeReplace.call(replacement, symbols, function (match, ch) {
      var capture;
      switch (ch.charAt(0)) {
        case '$': return '$';
        case '&': return matched;
        case '`': return str.slice(0, position);
        case "'": return str.slice(tailPos);
        case '<':
          capture = namedCaptures[ch.slice(1, -1)];
          break;
        default: // \d\d?
          var n = +ch;
          if (n === 0) return match;
          if (n > m) {
            var f = floor(n / 10);
            if (f === 0) return match;
            if (f <= m) return captures[f - 1] === undefined ? ch.charAt(1) : captures[f - 1] + ch.charAt(1);
            return match;
          }
          capture = captures[n - 1];
      }
      return capture === undefined ? '' : capture;
    });
  }
});


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Inventario/TomaInventario.vue?vue&type=template&id=fb79f438&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Inventario/TomaInventario.vue?vue&type=template&id=fb79f438& ***!
  \***************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-card",
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-button",
                    {
                      attrs: { variant: "outline-success" },
                      on: {
                        click: function ($event) {
                          return _vm.abrirModalTomaInventario(null)
                        },
                      },
                    },
                    [_vm._v(" Nueva Toma de Inventario ")]
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-input-group",
                    [
                      _c("b-form-input", {
                        attrs: { placeholder: "Buscar...", state: true },
                        model: {
                          value: _vm.buscar,
                          callback: function ($$v) {
                            _vm.buscar = $$v
                          },
                          expression: "buscar",
                        },
                      }),
                      _vm._v(" "),
                      _c(
                        "b-input-group-append",
                        [
                          _c(
                            "b-button",
                            {
                              attrs: { variant: "outline-success" },
                              on: {
                                click: function ($event) {
                                  return _vm.listarTomaInventario()
                                },
                              },
                            },
                            [_vm._v(" Buscar ")]
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayTable,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c("b-table", {
            attrs: {
              hover: "",
              striped: "",
              responsive: "",
              bordered: "",
              small: "",
              "no-border-collapse": "",
              items: _vm.arrayTomaInventario,
              fields: _vm.fields,
            },
            scopedSlots: _vm._u([
              {
                key: "cell(opcion)",
                fn: function (data) {
                  return [
                    _c(
                      "b-button",
                      {
                        staticClass: "btn-icon rounded-circle text-center",
                        attrs: {
                          variant:
                            data.item.estado === "A"
                              ? "flat-danger"
                              : data.item.p_activo
                              ? "flat-danger"
                              : "flat-success",
                          title:
                            data.item.estado === "A"
                              ? "Anulación deshabilitada"
                              : data.item.p_activo
                              ? "anulado"
                              : "anular",
                          disabled: data.item.estado === "A",
                        },
                        on: {
                          click: function ($event) {
                            data.item.estado !== "A"
                              ? _vm.abrirModalAnulacion(data.item)
                              : null
                          },
                        },
                      },
                      [
                        _c("feather-icon", {
                          attrs: {
                            icon:
                              data.item.estado === "A"
                                ? "LockIcon"
                                : data.item.p_activo
                                ? "LockIcon"
                                : "UnlockIcon",
                          },
                        }),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-button",
                      {
                        staticClass: "btn-icon rounded-circle text-center",
                        attrs: { variant: "flat-primary", title: "Imprimir" },
                        on: {
                          click: function ($event) {
                            return _vm.descargarPDF(data.item)
                          },
                        },
                      },
                      [_c("feather-icon", { attrs: { icon: "FileTextIcon" } })],
                      1
                    ),
                  ]
                },
              },
            ]),
          }),
          _vm._v(" "),
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { cols: "2" } },
                [
                  _c(
                    "b-form-group",
                    { staticClass: "mb-0" },
                    [
                      _c(
                        "label",
                        { staticClass: "d-inline-block text-sm-left mr-50" },
                        [_vm._v("Por página")]
                      ),
                      _vm._v(" "),
                      _c("b-form-select", {
                        staticClass: "w-50",
                        attrs: { size: "sm", options: _vm.pageOptions },
                        on: {
                          input: function ($event) {
                            return _vm.listarTomaInventario()
                          },
                        },
                        model: {
                          value: _vm.perPage,
                          callback: function ($$v) {
                            _vm.perPage = $$v
                          },
                          expression: "perPage",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-col", { attrs: { cols: "10" } }, [
                _c(
                  "span",
                  { staticStyle: { float: "right" } },
                  [
                    _c("b-pagination", {
                      staticClass: "my-0",
                      attrs: {
                        "total-rows": _vm.totalRows,
                        "per-page": _vm.perPage,
                        align: "center",
                        size: "sm",
                      },
                      model: {
                        value: _vm.currentPage,
                        callback: function ($$v) {
                          _vm.currentPage = $$v
                        },
                        expression: "currentPage",
                      },
                    }),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: { "hide-footer": "", centered: "", title: _vm.title },
          model: {
            value: _vm.modalNuevaTomaInventario,
            callback: function ($$v) {
              _vm.modalNuevaTomaInventario = $$v
            },
            expression: "modalNuevaTomaInventario",
          },
        },
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Relevado Por ")]),
                      _vm._v(" "),
                      _c("b-form-select", {
                        attrs: {
                          options: _vm.arrayPersonas,
                          state: _vm.objTomaInventario.relevado_por != null,
                        },
                        model: {
                          value: _vm.objTomaInventario.relevado_por,
                          callback: function ($$v) {
                            _vm.$set(_vm.objTomaInventario, "relevado_por", $$v)
                          },
                          expression: "objTomaInventario.relevado_por",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Validado Por ")]),
                      _vm._v(" "),
                      _c("b-form-select", {
                        attrs: {
                          options: _vm.arrayUsuarios,
                          state: _vm.objTomaInventario.validado_por != null,
                        },
                        model: {
                          value: _vm.objTomaInventario.validado_por,
                          callback: function ($$v) {
                            _vm.$set(_vm.objTomaInventario, "validado_por", $$v)
                          },
                          expression: "objTomaInventario.validado_por",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "12" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Almacen ")]),
                      _vm._v(" "),
                      _c("b-form-select", {
                        attrs: {
                          options: _vm.arrayAlmacen,
                          state: _vm.objTomaInventario.id_almacen != null,
                        },
                        on: {
                          change: function ($event) {
                            return _vm.listarMedicamento()
                          },
                        },
                        model: {
                          value: _vm.objTomaInventario.id_almacen,
                          callback: function ($$v) {
                            _vm.$set(_vm.objTomaInventario, "id_almacen", $$v)
                          },
                          expression: "objTomaInventario.id_almacen",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "12" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Nota ")]),
                      _vm._v(" "),
                      _c("b-form-textarea", {
                        attrs: {
                          rows: "3",
                          placeholder: "Nota",
                          state: _vm.objTomaInventario.nota != "",
                        },
                        model: {
                          value: _vm.objTomaInventario.nota,
                          callback: function ($$v) {
                            _vm.$set(_vm.objTomaInventario, "nota", $$v)
                          },
                          expression: "objTomaInventario.nota",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "12" } },
                [
                  _c("b-table", {
                    attrs: {
                      hover: "",
                      striped: "",
                      responsive: "",
                      bordered: "",
                      small: "",
                      "no-border-collapse": "",
                      items: _vm.arrayMedicamentos,
                      fields: _vm.fields2,
                    },
                    scopedSlots: _vm._u([
                      {
                        key: "head(seleccion)",
                        fn: function () {
                          return [
                            _c(
                              "b-form-checkbox",
                              {
                                on: { change: _vm.toggleSeleccionarTodos },
                                model: {
                                  value: _vm.seleccionarTodos,
                                  callback: function ($$v) {
                                    _vm.seleccionarTodos = $$v
                                  },
                                  expression: "seleccionarTodos",
                                },
                              },
                              [_vm._v("Seleccionar Todos")]
                            ),
                          ]
                        },
                        proxy: true,
                      },
                      {
                        key: "cell(id)",
                        fn: function (data) {
                          return [
                            _vm._v(
                              "\n                  " +
                                _vm._s(data.item.id) +
                                "\n              "
                            ),
                          ]
                        },
                      },
                      {
                        key: "cell(item)",
                        fn: function (data) {
                          return [
                            _vm._v(
                              "\n                  " +
                                _vm._s(data.item.name) +
                                "\n              "
                            ),
                          ]
                        },
                      },
                      {
                        key: "cell(seleccion)",
                        fn: function (data) {
                          return [
                            _c("b-form-checkbox", {
                              model: {
                                value: data.item.selected,
                                callback: function ($$v) {
                                  _vm.$set(data.item, "selected", $$v)
                                },
                                expression: "data.item.selected",
                              },
                            }),
                          ]
                        },
                      },
                    ]),
                  }),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayTomaInventario,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-left",
              attrs: { variant: "outline-danger" },
              on: {
                click: function ($event) {
                  _vm.modalNuevaTomaInventario = false
                },
              },
            },
            [_vm._v("Cancelar")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-right",
              attrs: {
                variant: "outline-success",
                disabled: !_vm.isFormValid(),
              },
              on: {
                click: function ($event) {
                  return _vm.crearTomaInventario()
                },
              },
            },
            [_vm._v("Crear")]
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: {
            "hide-footer": "",
            centered: "",
            title: "ANULAR DOCUMENTO ALMACÉN",
            size: "md",
          },
          model: {
            value: _vm.modalAnulacion,
            callback: function ($$v) {
              _vm.modalAnulacion = $$v
            },
            expression: "modalAnulacion",
          },
        },
        [
          _c(
            "b-form-group",
            [
              _c("label", [_vm._v(" Glosa ")]),
              _vm._v(" "),
              _c("b-form-textarea", {
                attrs: {
                  rows: "3",
                  placeholder: "Glosa",
                  state: _vm.objTomaInventario.memo_anular != "",
                },
                model: {
                  value: _vm.objTomaInventario.memo_anular,
                  callback: function ($$v) {
                    _vm.$set(_vm.objTomaInventario, "memo_anular", $$v)
                  },
                  expression: "objTomaInventario.memo_anular",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayAnulacion,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-left",
              attrs: { variant: "outline-danger" },
              on: {
                click: function ($event) {
                  _vm.modalAnulacion = false
                },
              },
            },
            [_vm._v(" Cancelar ")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-right",
              attrs: { variant: "outline-success" },
              on: {
                click: function ($event) {
                  return _vm.anularTomaInventario()
                },
              },
            },
            [_vm._v(" Anular ")]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/Inventario/TomaInventario.vue":
/*!**************************************************************!*\
  !*** ./resources/js/src/views/Inventario/TomaInventario.vue ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TomaInventario_vue_vue_type_template_id_fb79f438___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TomaInventario.vue?vue&type=template&id=fb79f438& */ "./resources/js/src/views/Inventario/TomaInventario.vue?vue&type=template&id=fb79f438&");
/* harmony import */ var _TomaInventario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TomaInventario.vue?vue&type=script&lang=js& */ "./resources/js/src/views/Inventario/TomaInventario.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _TomaInventario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TomaInventario_vue_vue_type_template_id_fb79f438___WEBPACK_IMPORTED_MODULE_0__["render"],
  _TomaInventario_vue_vue_type_template_id_fb79f438___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/Inventario/TomaInventario.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/Inventario/TomaInventario.vue?vue&type=script&lang=js&":
/*!***************************************************************************************!*\
  !*** ./resources/js/src/views/Inventario/TomaInventario.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TomaInventario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./TomaInventario.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Inventario/TomaInventario.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TomaInventario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/Inventario/TomaInventario.vue?vue&type=template&id=fb79f438&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/src/views/Inventario/TomaInventario.vue?vue&type=template&id=fb79f438& ***!
  \*********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TomaInventario_vue_vue_type_template_id_fb79f438___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./TomaInventario.vue?vue&type=template&id=fb79f438& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Inventario/TomaInventario.vue?vue&type=template&id=fb79f438&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TomaInventario_vue_vue_type_template_id_fb79f438___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TomaInventario_vue_vue_type_template_id_fb79f438___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);