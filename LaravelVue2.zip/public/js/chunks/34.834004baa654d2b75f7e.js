(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[34],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Despacho/EditarDestino.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Despacho/EditarDestino.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      // paginación
      pageOptions: [50, 100, 200, 500],
      currentPage: 1,
      totalRows: 1,
      perPage: 50,
      arrayDocumentos: [],
      fields: [{
        key: 'codDocAlm',
        label: 'código'
      }, {
        key: 'ca_cho_fer',
        label: 'chofer'
      }, {
        key: 'va_pla_caa',
        label: 'placa'
      }, {
        key: 'origen',
        label: 'origen'
      }, {
        key: 'destino',
        label: 'destino'
      }, {
        key: 'fecReg',
        label: 'fecha'
      }, {
        key: 'codDocAlmPad',
        label: 'padre'
      }, {
        key: 'tipo_doc',
        label: 'tipo documento'
      }, {
        key: 'activo',
        label: 'estado',
        "class": 'text-center'
      }, {
        key: 'accion',
        label: 'acción',
        "class": 'text-center text-nowrap'
      }],
      estado: [{
        0: 'INACTIVO',
        1: 'ACTIVO'
      }, {
        0: 'light-danger',
        1: 'light-success'
      }],
      overlayTable: false,
      buscar: '',
      desde: null,
      hasta: null,
      arraySucursales: [],
      overlayStore: false,
      modalOrigen: false,
      destino: null,
      origen: null,
      tipoDoc: 0,
      id: 0
    };
  },
  mounted: function mounted() {
    this.desde = this.$moment().startOf('month').format('YYYY-MM-DD');
    this.hasta = this.$moment().format('YYYY-MM-DD');
    this.listarDocAlmacen();
    this.listarSucursales();
  },
  watch: {
    currentPage: function currentPage(newPage) {
      this.currentPage = newPage;
      this.listarDocAlmacen();
    }
  },
  methods: {
    abrirModal: function abrirModal(item) {
      console.log(item);
      this.id = item.codDocAlm;
      this.origen = item.sucOrigen;
      this.destino = item.sucDestino;
      this.tipoDoc = item.codTipDoc;
      this.modalOrigen = true;
    },
    listarDocAlmacen: function listarDocAlmacen() {
      var _this = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarDocAlmacenRe?perPage=' + this.perPage + '&page=' + this.currentPage + '&buscar=' + this.buscar + '&fecha_inicio=' + this.desde + '&fecha_fin=' + this.hasta).then(function (res) {
        _this.arrayDocumentos = res.data.data;
        _this.totalRows = res.data.total;
        console.log(_this.arrayDocumentos);
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this.overlayTable = false;
      });
    },
    editarSucursales: function editarSucursales() {
      var _this2 = this;

      this.overlayStore = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/editarSucursales', {
        'id': this.id,
        'tipo': this.tipoDoc,
        'sucursal': this.destino
      }).then(function (res) {
        _this2.listarDocAlmacen();

        _this2.modalOrigen = false;

        _this2.pop_up('Éxito', 'Guardado Correctamente.', 'success');
      })["catch"](function (err) {
        console.log(err);

        _this2.pop_up('Error', 'Error al Guardar.', 'error');
      })["finally"](function () {
        _this2.overlayStore = false;
      });
    },
    listarSucursales: function listarSucursales() {
      var _this3 = this;

      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarSelectSucursal').then(function (res) {
        for (var index = 0; index < res.data.length; index++) {
          _this3.arraySucursales.push({
            value: res.data[index].codSuc,
            text: res.data[index].nombre
          });
        }
      })["catch"](function (err) {
        console.log(err);
      });
    },
    dateFormat: function dateFormat(date) {
      var fecha = '';
      if (date != null) fecha = this.$moment(date).format('DD-MM-YYYY');
      return fecha;
    },
    pop_up: function pop_up(title, text, icon) {
      this.$swal({
        title: title,
        text: text,
        icon: icon,
        showConfirmButton: false,
        timer: 2000,
        customClass: {
          confirmButton: 'btn btn-primary'
        },
        buttonsStyling: false
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Despacho/EditarDestino.vue?vue&type=template&id=1054b9e2&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Despacho/EditarDestino.vue?vue&type=template&id=1054b9e2& ***!
  \************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-card",
        [
          _c(
            "b-row",
            [
              _c("b-col", { attrs: { md: "12" } }, [
                _c(
                  "div",
                  { staticClass: "d-flex align-items-center float-right" },
                  [
                    _c("b-form-input", {
                      attrs: { placeholder: "Buscar...", state: true },
                      model: {
                        value: _vm.buscar,
                        callback: function ($$v) {
                          _vm.buscar = $$v
                        },
                        expression: "buscar",
                      },
                    }),
                    _vm._v(" "),
                    _c("b-form-datepicker", {
                      staticClass: "ml-2",
                      attrs: {
                        "date-format-options": {
                          year: "numeric",
                          month: "numeric",
                          day: "numeric",
                        },
                        "selected-variant": "primary",
                        "button-variant": "primary",
                        state: true,
                      },
                      model: {
                        value: _vm.desde,
                        callback: function ($$v) {
                          _vm.desde = $$v
                        },
                        expression: "desde",
                      },
                    }),
                    _vm._v(" "),
                    _c("b-form-datepicker", {
                      staticClass: "mx-2",
                      attrs: {
                        "date-format-options": {
                          year: "numeric",
                          month: "numeric",
                          day: "numeric",
                        },
                        "selected-variant": "primary",
                        "button-variant": "primary",
                        state: true,
                      },
                      model: {
                        value: _vm.hasta,
                        callback: function ($$v) {
                          _vm.hasta = $$v
                        },
                        expression: "hasta",
                      },
                    }),
                    _vm._v(" "),
                    _c(
                      "b-button",
                      {
                        attrs: { variant: "outline-success" },
                        on: {
                          click: function ($event) {
                            return _vm.listarDocAlmacen()
                          },
                        },
                      },
                      [
                        _c("feather-icon", {
                          attrs: { icon: "SearchIcon", size: "16" },
                        }),
                      ],
                      1
                    ),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayTable,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c("b-table", {
            attrs: {
              hover: "",
              striped: "",
              responsive: "",
              bordered: "",
              small: "",
              "no-border-collapse": "",
              items: _vm.arrayDocumentos,
              fields: _vm.fields,
            },
            scopedSlots: _vm._u([
              {
                key: "cell(fecReg)",
                fn: function (data) {
                  return [
                    _vm._v(
                      "\n                " +
                        _vm._s(_vm.dateFormat(data.item.fecReg)) +
                        "\n            "
                    ),
                  ]
                },
              },
              {
                key: "cell(activo)",
                fn: function (data) {
                  return [
                    _c(
                      "b-badge",
                      { attrs: { variant: _vm.estado[1][data.item.activo] } },
                      [
                        _vm._v(
                          "\n                    " +
                            _vm._s(_vm.estado[0][data.item.activo]) +
                            "\n                "
                        ),
                      ]
                    ),
                  ]
                },
              },
              {
                key: "cell(accion)",
                fn: function (data) {
                  return [
                    _c(
                      "div",
                      { staticStyle: { "text-align": "center" } },
                      [
                        _c(
                          "b-button",
                          {
                            staticClass: "btn-icon rounded-circle text-center",
                            attrs: { variant: "flat-info", title: "editar" },
                            on: {
                              click: function ($event) {
                                return _vm.abrirModal(data.item)
                              },
                            },
                          },
                          [_c("feather-icon", { attrs: { icon: "EditIcon" } })],
                          1
                        ),
                      ],
                      1
                    ),
                  ]
                },
              },
            ]),
          }),
          _vm._v(" "),
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { cols: "2" } },
                [
                  _c(
                    "b-form-group",
                    { staticClass: "mb-0" },
                    [
                      _c(
                        "label",
                        { staticClass: "d-inline-block text-sm-left mr-50" },
                        [_vm._v("Por página")]
                      ),
                      _vm._v(" "),
                      _c("b-form-select", {
                        staticClass: "w-50",
                        attrs: { size: "sm", options: _vm.pageOptions },
                        on: {
                          input: function ($event) {
                            return _vm.listarDocAlmacen()
                          },
                        },
                        model: {
                          value: _vm.perPage,
                          callback: function ($$v) {
                            _vm.perPage = $$v
                          },
                          expression: "perPage",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-col", { attrs: { cols: "10" } }, [
                _c(
                  "span",
                  { staticStyle: { float: "right" } },
                  [
                    _c("b-pagination", {
                      staticClass: "my-0",
                      attrs: {
                        "total-rows": _vm.totalRows,
                        "per-page": _vm.perPage,
                        align: "center",
                        size: "sm",
                      },
                      model: {
                        value: _vm.currentPage,
                        callback: function ($$v) {
                          _vm.currentPage = $$v
                        },
                        expression: "currentPage",
                      },
                    }),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: {
            centered: "",
            title: "CAMBIAR SUCURSAL DESTINO",
            "hide-footer": "",
          },
          model: {
            value: _vm.modalOrigen,
            callback: function ($$v) {
              _vm.modalOrigen = $$v
            },
            expression: "modalOrigen",
          },
        },
        [
          _c(
            "b-form-group",
            [
              _c("label", [_vm._v(" Sucursal Origen ")]),
              _vm._v(" "),
              _c("b-form-select", {
                attrs: {
                  options: _vm.arraySucursales,
                  state: _vm.origen != null,
                  disabled: "",
                },
                model: {
                  value: _vm.origen,
                  callback: function ($$v) {
                    _vm.origen = $$v
                  },
                  expression: "origen",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-form-group",
            [
              _c("label", [_vm._v(" Sucursal Destino ")]),
              _vm._v(" "),
              _c("b-form-select", {
                attrs: {
                  options: _vm.arraySucursales,
                  state: _vm.destino != null,
                },
                model: {
                  value: _vm.destino,
                  callback: function ($$v) {
                    _vm.destino = $$v
                  },
                  expression: "destino",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayStore,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-left",
              attrs: { variant: "outline-danger" },
              on: {
                click: function ($event) {
                  _vm.modalOrigen = false
                },
              },
            },
            [_vm._v(" Cerrar ")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-right",
              attrs: { variant: "outline-success" },
              on: {
                click: function ($event) {
                  return _vm.editarSucursales()
                },
              },
            },
            [_vm._v(" Guardar ")]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/Despacho/EditarDestino.vue":
/*!***********************************************************!*\
  !*** ./resources/js/src/views/Despacho/EditarDestino.vue ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _EditarDestino_vue_vue_type_template_id_1054b9e2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./EditarDestino.vue?vue&type=template&id=1054b9e2& */ "./resources/js/src/views/Despacho/EditarDestino.vue?vue&type=template&id=1054b9e2&");
/* harmony import */ var _EditarDestino_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./EditarDestino.vue?vue&type=script&lang=js& */ "./resources/js/src/views/Despacho/EditarDestino.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _EditarDestino_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _EditarDestino_vue_vue_type_template_id_1054b9e2___WEBPACK_IMPORTED_MODULE_0__["render"],
  _EditarDestino_vue_vue_type_template_id_1054b9e2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/Despacho/EditarDestino.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/Despacho/EditarDestino.vue?vue&type=script&lang=js&":
/*!************************************************************************************!*\
  !*** ./resources/js/src/views/Despacho/EditarDestino.vue?vue&type=script&lang=js& ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EditarDestino_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./EditarDestino.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Despacho/EditarDestino.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EditarDestino_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/Despacho/EditarDestino.vue?vue&type=template&id=1054b9e2&":
/*!******************************************************************************************!*\
  !*** ./resources/js/src/views/Despacho/EditarDestino.vue?vue&type=template&id=1054b9e2& ***!
  \******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_EditarDestino_vue_vue_type_template_id_1054b9e2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./EditarDestino.vue?vue&type=template&id=1054b9e2& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Despacho/EditarDestino.vue?vue&type=template&id=1054b9e2&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_EditarDestino_vue_vue_type_template_id_1054b9e2___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_EditarDestino_vue_vue_type_template_id_1054b9e2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);