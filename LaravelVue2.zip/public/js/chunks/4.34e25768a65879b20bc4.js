(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[4],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var C_Users_LP_4_Downloads_WEB_MODULOS_1_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var vue_apexcharts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue-apexcharts */ "./node_modules/vue-apexcharts/dist/vue-apexcharts.js");
/* harmony import */ var vue_apexcharts__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(vue_apexcharts__WEBPACK_IMPORTED_MODULE_3__);



//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'PorCanal',
  components: {
    apexchart: vue_apexcharts__WEBPACK_IMPORTED_MODULE_3___default.a
  },
  props: {
    canal: {
      type: Array,
      required: true
    }
  },
  data: function data() {
    return {
      series: [{
        data: []
      }],
      chartOptions: {
        chart: {
          type: "bar",
          height: 350,
          stacked: true,
          stackType: "normal",
          toolbar: {
            show: false
          },
          zoom: {
            enabled: false
          }
        },
        legend: {
          show: false
        },
        tooltip: {
          theme: "dark",
          x: {
            show: true
          },
          y: {
            title: {
              formatter: function formatter() {
                return " (N° de PDV): ";
              }
            }
          }
        },
        plotOptions: {
          bar: {
            borderRadius: 10,
            horizontal: true,
            distributed: true
          }
        },
        colors: ["#2ABF5E"],
        xaxis: {
          categories: [],
          dataLabels: {
            enabled: true,
            textAnchor: "middle",
            style: {
              colors: "#FFFFFF"
            },
            dropShadow: {
              enabled: true
            }
          },
          labels: {
            style: {
              colors: "#FFFFFF",
              fontSize: "11px",
              fontFamily: "Helvetica, Arial, sans-serif"
            }
          }
        },
        yaxis: {
          labels: {
            style: {
              colors: "#FFFFFF",
              fontSize: "12px",
              fontFamily: "Helvetica, Arial, sans-serif",
              fontWeight: 40,
              cssClass: "apexcharts-xaxis-label"
            }
          },
          tooltip: {
            enabled: true
          }
        }
      }
    };
  },
  watch: {
    canal: {
      handler: 'actualizarCanal',
      immediate: true
    }
  },
  methods: {
    actualizarCanal: function actualizarCanal() {
      var series = [];
      var labels = [];
      this.canal.forEach(function (item) {
        series.push(item.valor);
        labels.push(item.nombre);
      });
      this.series = [{
        data: series
      }];
      this.chartOptions = Object(C_Users_LP_4_Downloads_WEB_MODULOS_1_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(C_Users_LP_4_Downloads_WEB_MODULOS_1_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, this.chartOptions), {}, {
        xaxis: Object(C_Users_LP_4_Downloads_WEB_MODULOS_1_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(C_Users_LP_4_Downloads_WEB_MODULOS_1_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, this.chartOptions.xaxis), {}, {
          categories: labels
        })
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var C_Users_LP_4_Downloads_WEB_MODULOS_1_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var vue_apexcharts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue-apexcharts */ "./node_modules/vue-apexcharts/dist/vue-apexcharts.js");
/* harmony import */ var vue_apexcharts__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(vue_apexcharts__WEBPACK_IMPORTED_MODULE_3__);



//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'PorRegional',
  components: {
    apexchart: vue_apexcharts__WEBPACK_IMPORTED_MODULE_3___default.a
  },
  props: {
    regional: {
      type: Array,
      required: true
    }
  },
  data: function data() {
    return {
      series: [{
        data: [400, 430, 448, 470, 540, 580, 500]
      }],
      chartOptions: {
        chart: {
          type: "bar",
          height: 350,
          stacked: true,
          stackType: "normal",
          toolbar: {
            show: false
          },
          zoom: {
            enabled: false
          }
        },
        legend: {
          show: false
        },
        tooltip: {
          theme: "dark",
          x: {
            show: true
          },
          y: {
            title: {
              formatter: function formatter() {
                return " (N° de PDV): ";
              }
            }
          }
        },
        plotOptions: {
          bar: {
            borderRadius: 4,
            horizontal: true,
            distributed: true
          }
        },
        xaxis: {
          categories: [],
          dataLabels: {
            enabled: true,
            textAnchor: "middle",
            style: {
              colors: "#FFFFFF"
            },
            dropShadow: {
              enabled: true
            }
          },
          labels: {
            style: {
              colors: "#FFFFFF",
              fontSize: "11px",
              fontFamily: "Helvetica, Arial, sans-serif"
            }
          }
        },
        yaxis: {
          labels: {
            style: {
              colors: "#FFFFFF",
              fontSize: "12px",
              fontFamily: "Helvetica, Arial, sans-serif",
              fontWeight: 40,
              cssClass: "apexcharts-xaxis-label"
            }
          },
          tooltip: {
            enabled: true
          }
        }
      }
    };
  },
  watch: {
    regional: {
      handler: 'actualizarRegional',
      immediate: true
    }
  },
  methods: {
    actualizarRegional: function actualizarRegional() {
      var series = [];
      var labels = [];
      this.regional.forEach(function (item) {
        series.push(item.valor);
        labels.push(item.nombre);
      });
      this.series = [{
        data: series
      }];
      this.chartOptions = Object(C_Users_LP_4_Downloads_WEB_MODULOS_1_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(C_Users_LP_4_Downloads_WEB_MODULOS_1_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, this.chartOptions), {}, {
        xaxis: Object(C_Users_LP_4_Downloads_WEB_MODULOS_1_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(C_Users_LP_4_Downloads_WEB_MODULOS_1_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, this.chartOptions.xaxis), {}, {
          categories: labels
        })
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.number.to-fixed.js */ "./node_modules/core-js/modules/es.number.to-fixed.js");
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var vue_apexcharts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-apexcharts */ "./node_modules/vue-apexcharts/dist/vue-apexcharts.js");
/* harmony import */ var vue_apexcharts__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_apexcharts__WEBPACK_IMPORTED_MODULE_2__);


//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'PorTipo',
  components: {
    apexchart: vue_apexcharts__WEBPACK_IMPORTED_MODULE_2___default.a
  },
  props: {
    persona: {
      type: Number,
      required: true
    },
    organizacion: {
      type: Number,
      required: true
    }
  },
  data: function data() {
    return {
      series: [50, 50],
      chartOptions: {
        chart: {
          height: 315,
          type: 'pie'
        },
        legend: {
          show: true,
          labels: {
            colors: ["#FFFFFF"]
          },
          horizontalAlign: 'center',
          position: 'top'
        },
        labels: ['ORGANIZACIÓN', 'PERSONA'],
        colors: ['#F29441', '#0066CC']
      }
    };
  },
  watch: {
    persona: function persona(newPersona, oldPersona) {
      this.actualizarSeries();
    },
    organizacion: function organizacion(newOrganizacion, oldOrganizacion) {
      this.actualizarSeries();
    }
  },
  methods: {
    actualizarSeries: function actualizarSeries() {
      this.series = [this.organizacion, this.persona];
    },
    porcentaje: function porcentaje(org, per, tipo) {
      var total = org + per;
      var resultado = 0;

      if (org > 0 && per > 0) {
        if (tipo == 1) resultado = org * 100 / total;else resultado = per * 100 / total;
        resultado = resultado.toFixed(1);
      }

      return resultado;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/Visitas.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/layouts/components/GraficosDashboard/Visitas.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.number.to-fixed.js */ "./node_modules/core-js/modules/es.number.to-fixed.js");
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var vue_apexcharts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-apexcharts */ "./node_modules/vue-apexcharts/dist/vue-apexcharts.js");
/* harmony import */ var vue_apexcharts__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_apexcharts__WEBPACK_IMPORTED_MODULE_2__);


//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Visitas',
  components: {
    apexchart: vue_apexcharts__WEBPACK_IMPORTED_MODULE_2___default.a
  },
  props: {
    visitas: {
      type: Array,
      required: true
    }
  },
  data: function data() {
    return {
      series: [{
        name: 'Visitas Efectivas',
        type: 'column',
        data: []
      }, {
        name: 'Visitas del Día',
        type: 'area',
        data: []
      }],
      chartOptions: {
        dataLabels: {
          enabled: true,
          enabledOnSeries: undefined,
          formatter: function formatter(val, opts) {
            return val;
          }
        },
        chart: {
          height: 500,
          type: 'line',
          stacked: false,
          toolbar: {
            show: false
          },
          zoom: {
            enabled: false
          }
        },
        stroke: {
          width: [0, 2, 5],
          curve: 'smooth'
        },
        plotOptions: {
          bar: {
            columnWidth: '70%'
          }
        },
        fill: {
          opacity: [0.85, 0.25, 1],
          gradient: {
            inverseColors: false,
            shade: 'light',
            type: "vertical",
            opacityFrom: 0.85,
            opacityTo: 0.55,
            stops: [0, 100, 100, 100]
          }
        },
        labels: [],
        markers: {
          size: 0
        },
        xaxis: {
          type: 'date',
          labels: {
            style: {
              colors: '#FFFFFF',
              fontSize: '12px',
              fontFamily: 'Helvetica, Arial, sans-serif',
              fontWeight: 400,
              cssClass: 'apexcharts-xaxis-label'
            }
          }
        },
        yaxis: {
          title: {
            text: 'Visitas',
            style: {
              color: '#FFFFFF'
            }
          },
          min: 0,
          labels: {
            style: {
              colors: '#FFFFFF',
              fontSize: '12px',
              fontFamily: 'Helvetica, Arial, sans-serif',
              fontWeight: 400,
              cssClass: 'apexcharts-xaxis-label'
            }
          }
        },
        legend: {
          show: true,
          labels: {
            colors: ["#fff"]
          }
        },
        tooltip: {
          enabled: true,
          theme: "dark",
          shared: true,
          intersect: false,
          y: {
            formatter: function formatter(y) {
              if (typeof y !== "undefined") {
                return y.toFixed(0) + " visitas";
              }

              return y;
            }
          }
        }
      }
    };
  },
  watch: {
    visitas: {
      handler: function handler(newVal, oldVal) {
        this.actualizarSeries(newVal);
      },
      immediate: true
    }
  },
  methods: {
    actualizarSeries: function actualizarSeries(data) {
      var _this = this;

      var labels = data.map(function (row) {
        return _this.$moment(row['fecha']).format('DD-MM-YYYY');
      });
      var visitasEfectivas = data.map(function (row) {
        return row['metas'];
      });
      var visitasDia = data.map(function (row) {
        return row['visitas'];
      });
      this.chartOptions.labels[0] = labels[0];

      for (var index = 1; index < labels.length; index++) {
        this.chartOptions.labels[index] = labels[index];
      }

      this.series = [{
        name: 'Visitas Efectivas',
        type: 'column',
        data: visitasEfectivas
      }, {
        name: 'Visitas del Día',
        type: 'area',
        data: visitasDia
      }];
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Dashboard.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Dashboard.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _layouts_components_GraficosDashboard_Visitas_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/layouts/components/GraficosDashboard/Visitas.vue */ "./resources/js/src/layouts/components/GraficosDashboard/Visitas.vue");
/* harmony import */ var _layouts_components_GraficosDashboard_PorTipo_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/layouts/components/GraficosDashboard/PorTipo.vue */ "./resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue");
/* harmony import */ var _layouts_components_GraficosDashboard_PorCanal_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/layouts/components/GraficosDashboard/PorCanal.vue */ "./resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue");
/* harmony import */ var _layouts_components_GraficosDashboard_PorRegional_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/layouts/components/GraficosDashboard/PorRegional.vue */ "./resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Visitas: _layouts_components_GraficosDashboard_Visitas_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    PorTipo: _layouts_components_GraficosDashboard_PorTipo_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    PorCanal: _layouts_components_GraficosDashboard_PorCanal_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    PorRegional: _layouts_components_GraficosDashboard_PorRegional_vue__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  data: function data() {
    return {
      selectedMes: null,
      aDataMes: [{
        value: "01",
        text: "Ene"
      }, {
        value: "02",
        text: "Feb"
      }, {
        value: "03",
        text: "Mar"
      }, {
        value: "04",
        text: "Abr"
      }, {
        value: "05",
        text: "May"
      }, {
        value: "06",
        text: "Jun"
      }, {
        value: "07",
        text: "Jul"
      }, {
        value: "08",
        text: "Ago"
      }, {
        value: "09",
        text: "Sep"
      }, {
        value: "10",
        text: "Oct"
      }, {
        value: "11",
        text: "Nov"
      }, {
        value: "12",
        text: "Dic"
      }],
      selectedGestion: null,
      aDataGestion: [{
        value: "2024",
        text: "2024"
      }, {
        value: "2025",
        text: "2025"
      }, {
        value: "2026",
        text: "2026"
      }, {
        value: "2027",
        text: "2027"
      }],
      pdv: 0,
      usuario: 0,
      visitado: 0,
      sinVisita: 0,
      prospecto: 0,
      multipunto: 0,
      persona: 0,
      organizacion: 0,
      arrayCanal: [],
      arrayVisitas: [],
      arrayRegional: []
    };
  },
  mounted: function mounted() {
    this.selectedGestion = this.$moment().format('YYYY');
    this.selectedMes = this.$moment().format('MM');
    this.listar();
  },
  methods: {
    listar: function listar() {
      var _this = this;

      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/datosDashboard').then(function (res) {
        console.log(res.data);
        _this.persona = 235;
        _this.organizacion = 120;
        _this.arrayCanal = res.data['canal'];
        _this.arrayVisitas = res.data['visitas'];
        _this.arrayRegional = res.data['regional'];
      })["catch"](function (err) {
        console.log(err);
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue?vue&type=template&id=483b3c6a&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue?vue&type=template&id=483b3c6a& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("apexchart", {
        attrs: {
          type: "bar",
          height: "350",
          options: _vm.chartOptions,
          series: _vm.series,
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue?vue&type=template&id=3535a97f&":
/*!********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue?vue&type=template&id=3535a97f& ***!
  \********************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("apexchart", {
        attrs: {
          type: "bar",
          height: "350",
          options: _vm.chartOptions,
          series: _vm.series,
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue?vue&type=template&id=1c728814&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue?vue&type=template&id=1c728814& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("apexchart", {
        attrs: {
          type: "pie",
          height: "315",
          options: _vm.chartOptions,
          series: _vm.series,
        },
      }),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "d-flex justify-content-center" },
        [
          _c(
            "b-avatar",
            {
              staticStyle: { "background-color": "#F29441" },
              attrs: { size: "45px" },
            },
            [_c("span", [_vm._v(" " + _vm._s(_vm.organizacion) + " ")])]
          ),
          _vm._v(" "),
          _c(
            "b-avatar",
            {
              staticClass: "mx-1",
              staticStyle: { "background-color": "#0066CC" },
              attrs: { size: "45px" },
            },
            [_c("span", [_vm._v(" " + _vm._s(_vm.persona) + " ")])]
          ),
          _vm._v(" "),
          _c(
            "b-avatar",
            {
              staticStyle: { "background-color": "#F29441" },
              attrs: { size: "45px" },
            },
            [
              _c("span", [
                _vm._v(
                  " " +
                    _vm._s(_vm.porcentaje(_vm.organizacion, _vm.persona, 1)) +
                    "% "
                ),
              ]),
            ]
          ),
          _vm._v(" "),
          _c(
            "b-avatar",
            {
              staticClass: "ml-1",
              staticStyle: { "background-color": "#0066CC" },
              attrs: { size: "45px" },
            },
            [
              _c("span", [
                _vm._v(
                  " " +
                    _vm._s(_vm.porcentaje(_vm.organizacion, _vm.persona, 2)) +
                    "% "
                ),
              ]),
            ]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/Visitas.vue?vue&type=template&id=265767aa&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/layouts/components/GraficosDashboard/Visitas.vue?vue&type=template&id=265767aa& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("apexchart", {
        attrs: {
          type: "line",
          height: "500",
          options: _vm.chartOptions,
          series: _vm.series,
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Dashboard.vue?vue&type=template&id=d9e5d64c&":
/*!***********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Dashboard.vue?vue&type=template&id=d9e5d64c& ***!
  \***********************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-card",
        { staticClass: "statistics-body" },
        [
          _c(
            "b-row",
            { staticClass: "mb-2" },
            [
              _c("b-col", { attrs: { md: "6" } }, [
                _c("h4", { staticClass: "font-weight-bolder" }, [
                  _c("b", [_vm._v(" INDICADORES ")]),
                ]),
              ]),
              _vm._v(" "),
              _c("b-col", { attrs: { md: "6" } }, [
                _c(
                  "div",
                  { staticClass: "float-right" },
                  [
                    _c("b-form-select", {
                      staticStyle: { width: "fit-content" },
                      attrs: {
                        options: _vm.aDataMes,
                        state: _vm.selectedMes === null ? false : true,
                      },
                      model: {
                        value: _vm.selectedMes,
                        callback: function ($$v) {
                          _vm.selectedMes = $$v
                        },
                        expression: "selectedMes",
                      },
                    }),
                    _vm._v(" "),
                    _c("b-form-select", {
                      staticStyle: { width: "fit-content" },
                      attrs: {
                        options: _vm.aDataGestion,
                        state: _vm.selectedGestion === null ? false : true,
                      },
                      model: {
                        value: _vm.selectedGestion,
                        callback: function ($$v) {
                          _vm.selectedGestion = $$v
                        },
                        expression: "selectedGestion",
                      },
                    }),
                    _vm._v(" "),
                    _c(
                      "b-button",
                      {
                        attrs: {
                          variant: "outline-success btn-icon",
                          title: "Buscar",
                        },
                        on: {
                          click: function ($event) {
                            return _vm.listarGestionPDV()
                          },
                        },
                      },
                      [
                        _c("feather-icon", {
                          attrs: { icon: "SearchIcon", size: "18" },
                        }),
                      ],
                      1
                    ),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { md: "2" } },
                [
                  _c(
                    "b-media",
                    {
                      staticStyle: { cursor: "pointer" },
                      attrs: { "no-body": "" },
                    },
                    [
                      _c(
                        "b-media-aside",
                        [
                          _c(
                            "b-avatar",
                            { attrs: { size: "60", variant: "light-success" } },
                            [
                              _c("feather-icon", {
                                attrs: { size: "30", icon: "DatabaseIcon" },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("b-media-body", { staticClass: "my-auto" }, [
                        _c("h4", { staticClass: "font-weight-bolder mb-0" }, [
                          _vm._v(" " + _vm._s(_vm.pdv) + " "),
                        ]),
                        _vm._v(" "),
                        _c("h6", { staticClass: "font-weight-bolder mb-0" }, [
                          _vm._v(" Personal "),
                        ]),
                      ]),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "2" } },
                [
                  _c(
                    "b-media",
                    {
                      staticStyle: { cursor: "pointer" },
                      attrs: { "no-body": "" },
                    },
                    [
                      _c(
                        "b-media-aside",
                        [
                          _c(
                            "b-avatar",
                            { attrs: { size: "60", variant: "light-primary" } },
                            [
                              _c("feather-icon", {
                                attrs: { size: "30", icon: "MapPinIcon" },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("b-media-body", { staticClass: "my-auto" }, [
                        _c("h4", { staticClass: "font-weight-bolder mb-0" }, [
                          _vm._v(" " + _vm._s(_vm.multipunto) + " "),
                        ]),
                        _vm._v(" "),
                        _c("h6", { staticClass: "font-weight-bolder mb-0" }, [
                          _vm._v(" Sucursales "),
                        ]),
                      ]),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "2" } },
                [
                  _c(
                    "b-media",
                    {
                      staticStyle: { cursor: "pointer" },
                      attrs: { "no-body": "" },
                    },
                    [
                      _c(
                        "b-media-aside",
                        [
                          _c(
                            "b-avatar",
                            { attrs: { size: "60", variant: "light-info" } },
                            [
                              _c("feather-icon", {
                                attrs: { size: "30", icon: "UsersIcon" },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("b-media-body", { staticClass: "my-auto" }, [
                        _c("h4", { staticClass: "font-weight-bolder mb-0" }, [
                          _vm._v(" " + _vm._s(_vm.usuario) + " "),
                        ]),
                        _vm._v(" "),
                        _c("h6", { staticClass: "font-weight-bolder mb-0" }, [
                          _vm._v(" Equipos "),
                        ]),
                      ]),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "2" } },
                [
                  _c(
                    "b-media",
                    {
                      staticStyle: { cursor: "pointer" },
                      attrs: { "no-body": "" },
                    },
                    [
                      _c(
                        "b-media-aside",
                        [
                          _c(
                            "b-avatar",
                            { attrs: { size: "60", variant: "light-success" } },
                            [
                              _c("feather-icon", {
                                attrs: { size: "30", icon: "PhoneCallIcon" },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("b-media-body", { staticClass: "my-auto" }, [
                        _c("h4", { staticClass: "font-weight-bolder mb-0" }, [
                          _vm._v(" " + _vm._s(_vm.visitado) + " "),
                        ]),
                        _vm._v(" "),
                        _c("h6", { staticClass: "font-weight-bolder mb-0" }, [
                          _vm._v(" Multipuntos Visitados "),
                        ]),
                      ]),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "2" } },
                [
                  _c(
                    "b-media",
                    {
                      staticStyle: { cursor: "pointer" },
                      attrs: { "no-body": "" },
                    },
                    [
                      _c(
                        "b-media-aside",
                        [
                          _c(
                            "b-avatar",
                            { attrs: { size: "60", variant: "light-danger" } },
                            [
                              _c("feather-icon", {
                                attrs: { size: "30", icon: "PhoneOffIcon" },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("b-media-body", { staticClass: "my-auto" }, [
                        _c("h4", { staticClass: "font-weight-bolder mb-0" }, [
                          _vm._v(" " + _vm._s(_vm.sinVisita) + " "),
                        ]),
                        _vm._v(" "),
                        _c("h6", { staticClass: "font-weight-bolder mb-0" }, [
                          _vm._v(" Multipuntos sin Visitas "),
                        ]),
                      ]),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "2" } },
                [
                  _c(
                    "b-media",
                    {
                      staticStyle: { cursor: "pointer" },
                      attrs: { "no-body": "" },
                    },
                    [
                      _c(
                        "b-media-aside",
                        [
                          _c(
                            "b-avatar",
                            { attrs: { size: "60", variant: "light-warning" } },
                            [
                              _c("feather-icon", {
                                attrs: { size: "30", icon: "PhoneMissedIcon" },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("b-media-body", { staticClass: "my-auto" }, [
                        _c("h4", { staticClass: "font-weight-bolder mb-0" }, [
                          _vm._v(" " + _vm._s(_vm.prospecto) + " "),
                        ]),
                        _vm._v(" "),
                        _c("h6", { staticClass: "font-weight-bolder mb-0" }, [
                          _vm._v(" Puntos Prospectados "),
                        ]),
                      ]),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-row",
        [
          _c(
            "b-col",
            { attrs: { md: "4" } },
            [
              _c(
                "b-card",
                { attrs: { title: "FICHA CLINICA" } },
                [
                  _c("PorTipo", {
                    attrs: {
                      persona: _vm.persona,
                      organizacion: _vm.organizacion,
                    },
                  }),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-col",
            { attrs: { md: "4" } },
            [
              _c(
                "b-card",
                { attrs: { title: "FICHA CLINICA POR SUCURSAL" } },
                [_c("PorRegional", { attrs: { regional: _vm.arrayRegional } })],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-col",
            { attrs: { md: "4" } },
            [
              _c(
                "b-card",
                { attrs: { title: "CONSULTAS POR DEFINIR" } },
                [_c("PorCanal", { attrs: { canal: _vm.arrayCanal } })],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-card",
        { attrs: { title: "CONSULTAS MEDICAS" } },
        [_c("Visitas", { attrs: { visitas: _vm.arrayVisitas } })],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue":
/*!****************************************************************************!*\
  !*** ./resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PorCanal_vue_vue_type_template_id_483b3c6a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PorCanal.vue?vue&type=template&id=483b3c6a& */ "./resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue?vue&type=template&id=483b3c6a&");
/* harmony import */ var _PorCanal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PorCanal.vue?vue&type=script&lang=js& */ "./resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _PorCanal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _PorCanal_vue_vue_type_template_id_483b3c6a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _PorCanal_vue_vue_type_template_id_483b3c6a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************!*\
  !*** ./resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PorCanal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./PorCanal.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PorCanal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue?vue&type=template&id=483b3c6a&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue?vue&type=template&id=483b3c6a& ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PorCanal_vue_vue_type_template_id_483b3c6a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./PorCanal.vue?vue&type=template&id=483b3c6a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/PorCanal.vue?vue&type=template&id=483b3c6a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PorCanal_vue_vue_type_template_id_483b3c6a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PorCanal_vue_vue_type_template_id_483b3c6a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue":
/*!*******************************************************************************!*\
  !*** ./resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PorRegional_vue_vue_type_template_id_3535a97f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PorRegional.vue?vue&type=template&id=3535a97f& */ "./resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue?vue&type=template&id=3535a97f&");
/* harmony import */ var _PorRegional_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PorRegional.vue?vue&type=script&lang=js& */ "./resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _PorRegional_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _PorRegional_vue_vue_type_template_id_3535a97f___WEBPACK_IMPORTED_MODULE_0__["render"],
  _PorRegional_vue_vue_type_template_id_3535a97f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PorRegional_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./PorRegional.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PorRegional_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue?vue&type=template&id=3535a97f&":
/*!**************************************************************************************************************!*\
  !*** ./resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue?vue&type=template&id=3535a97f& ***!
  \**************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PorRegional_vue_vue_type_template_id_3535a97f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./PorRegional.vue?vue&type=template&id=3535a97f& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/PorRegional.vue?vue&type=template&id=3535a97f&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PorRegional_vue_vue_type_template_id_3535a97f___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PorRegional_vue_vue_type_template_id_3535a97f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue":
/*!***************************************************************************!*\
  !*** ./resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PorTipo_vue_vue_type_template_id_1c728814___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PorTipo.vue?vue&type=template&id=1c728814& */ "./resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue?vue&type=template&id=1c728814&");
/* harmony import */ var _PorTipo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PorTipo.vue?vue&type=script&lang=js& */ "./resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _PorTipo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _PorTipo_vue_vue_type_template_id_1c728814___WEBPACK_IMPORTED_MODULE_0__["render"],
  _PorTipo_vue_vue_type_template_id_1c728814___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PorTipo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./PorTipo.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PorTipo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue?vue&type=template&id=1c728814&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue?vue&type=template&id=1c728814& ***!
  \**********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PorTipo_vue_vue_type_template_id_1c728814___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./PorTipo.vue?vue&type=template&id=1c728814& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/PorTipo.vue?vue&type=template&id=1c728814&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PorTipo_vue_vue_type_template_id_1c728814___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PorTipo_vue_vue_type_template_id_1c728814___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/layouts/components/GraficosDashboard/Visitas.vue":
/*!***************************************************************************!*\
  !*** ./resources/js/src/layouts/components/GraficosDashboard/Visitas.vue ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Visitas_vue_vue_type_template_id_265767aa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Visitas.vue?vue&type=template&id=265767aa& */ "./resources/js/src/layouts/components/GraficosDashboard/Visitas.vue?vue&type=template&id=265767aa&");
/* harmony import */ var _Visitas_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Visitas.vue?vue&type=script&lang=js& */ "./resources/js/src/layouts/components/GraficosDashboard/Visitas.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Visitas_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Visitas_vue_vue_type_template_id_265767aa___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Visitas_vue_vue_type_template_id_265767aa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/layouts/components/GraficosDashboard/Visitas.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/layouts/components/GraficosDashboard/Visitas.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/layouts/components/GraficosDashboard/Visitas.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Visitas_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Visitas.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/Visitas.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Visitas_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/layouts/components/GraficosDashboard/Visitas.vue?vue&type=template&id=265767aa&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/src/layouts/components/GraficosDashboard/Visitas.vue?vue&type=template&id=265767aa& ***!
  \**********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Visitas_vue_vue_type_template_id_265767aa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Visitas.vue?vue&type=template&id=265767aa& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/layouts/components/GraficosDashboard/Visitas.vue?vue&type=template&id=265767aa&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Visitas_vue_vue_type_template_id_265767aa___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Visitas_vue_vue_type_template_id_265767aa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/Dashboard.vue":
/*!**********************************************!*\
  !*** ./resources/js/src/views/Dashboard.vue ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Dashboard_vue_vue_type_template_id_d9e5d64c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Dashboard.vue?vue&type=template&id=d9e5d64c& */ "./resources/js/src/views/Dashboard.vue?vue&type=template&id=d9e5d64c&");
/* harmony import */ var _Dashboard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Dashboard.vue?vue&type=script&lang=js& */ "./resources/js/src/views/Dashboard.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Dashboard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Dashboard_vue_vue_type_template_id_d9e5d64c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Dashboard_vue_vue_type_template_id_d9e5d64c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/Dashboard.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/Dashboard.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/src/views/Dashboard.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Dashboard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Dashboard.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Dashboard.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Dashboard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/Dashboard.vue?vue&type=template&id=d9e5d64c&":
/*!*****************************************************************************!*\
  !*** ./resources/js/src/views/Dashboard.vue?vue&type=template&id=d9e5d64c& ***!
  \*****************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Dashboard_vue_vue_type_template_id_d9e5d64c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Dashboard.vue?vue&type=template&id=d9e5d64c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Dashboard.vue?vue&type=template&id=d9e5d64c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Dashboard_vue_vue_type_template_id_d9e5d64c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Dashboard_vue_vue_type_template_id_d9e5d64c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);