(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[39],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/ListaFP.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Farmacia/ListaFP.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/web.url.js */ "./node_modules/core-js/modules/web.url.js");
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_4__);





//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      // paginación
      pageOptions: [50, 100, 200, 500],
      currentPage: 1,
      totalRows: 1,
      perPage: 50,
      buscar: '',
      modalAnulacion: false,
      overlayTable: false,
      arrayFicha: [],
      fields: [{
        key: 'p_nombre',
        label: 'persona'
      }, {
        key: 'p_sexo',
        label: 'sexo'
      }, {
        key: 'p_residencia',
        label: 'residencia'
      }, {
        key: 'p_telefono',
        label: 'teléfono',
        "class": 'text-center'
      }, {
        key: 'p_ci',
        label: 'ci',
        "class": 'text-center'
      }, {
        key: 'p_activo',
        label: 'estado',
        "class": 'text-center'
      }, {
        key: 'opcion',
        label: 'opción',
        "class": 'text-center text-nowrap'
      } // {key:'opcion', label:'opción', class:'text-center text-nowrap'}
      ],
      estado: [{
        0: 'INACTIVO',
        1: 'ACTIVO'
      }, {
        0: 'light-danger',
        1: 'light-success'
      }],
      $id_ficha_personal: null
    };
  },
  mounted: function mounted() {
    this.listarFicha();
  },
  methods: {
    imprimirFicha: function imprimirFicha(item) {
      var _this = this;

      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/imprimirFicha?id_ficha_personal=' + item.id_ficha_personal, {
        responseType: 'blob'
      }).then(function (res) {
        var url = window.URL.createObjectURL(new Blob([res.data], {
          type: 'application/pdf'
        }));
        var link = document.createElement('a');
        link.href = url;
        link.target = '_blank';
        link.click();
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this.overlayTable = false;
      });
    },
    listarFicha: function listarFicha() {
      var _this2 = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarFicha?perPage=' + this.perPage + '&page=' + this.currentPage + '&buscar=' + this.buscar).then(function (res) {
        _this2.arrayFicha = [];
        _this2.arrayFicha = res.data.data;
        _this2.totalRows = res.data.total;
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this2.overlayTable = false;
      });
    },
    editar: function editar(item) {
      this.$router.push({
        path: '/ficha_personal_editar',
        query: {
          id_ficha_personal: item.id_ficha_personal
        }
      });
    },
    abrirModalAnulacion: function abrirModalAnulacion(item) {
      this.id_ficha_personal = item.id_ficha_personal;
      this.modalAnulacion = true;
    },
    anular: function anular() {
      var _this3 = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/anularFicha', {
        id_ficha_personal: this.id_ficha_personal
      }).then(function () {
        _this3.listarFicha();

        _this3.modalAnulacion = false;

        _this3.pop_up('Anulado', 'La ficha ha sido anulada exitosamente.', 'success');
      })["catch"](function (err) {
        console.error(err);

        _this3.pop_up('Error', 'Ocurrió un error al intentar anular la ficha.', 'error');
      })["finally"](function () {
        _this3.overlayTable = false;
      });
    },
    pop_up: function pop_up(title, text, icon) {
      this.$swal({
        title: title,
        text: text,
        icon: icon,
        showConfirmButton: false,
        timer: 2000,
        customClass: {
          confirmButton: 'btn btn-primary'
        },
        buttonsStyling: false
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/ListaFP.vue?vue&type=template&id=08193c78&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Farmacia/ListaFP.vue?vue&type=template&id=08193c78& ***!
  \******************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-card",
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { md: "5" } },
                [
                  _c(
                    "b-button",
                    {
                      attrs: { variant: "outline-success" },
                      on: {
                        click: function ($event) {
                          return _vm.$router.push("/ficha_personal")
                        },
                      },
                    },
                    [_vm._v(" Nueva Ficha ")]
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-input-group",
                    [
                      _c("b-form-input", {
                        attrs: { placeholder: "Buscar...", state: true },
                        model: {
                          value: _vm.buscar,
                          callback: function ($$v) {
                            _vm.buscar = $$v
                          },
                          expression: "buscar",
                        },
                      }),
                      _vm._v(" "),
                      _c(
                        "b-input-group-append",
                        [
                          _c(
                            "b-button",
                            {
                              attrs: { variant: "outline-success" },
                              on: {
                                click: function ($event) {
                                  return _vm.listarFicha()
                                },
                              },
                            },
                            [_vm._v(" Buscar ")]
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayTable,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c("b-table", {
            attrs: {
              hover: "",
              striped: "",
              responsive: "",
              bordered: "",
              small: "",
              "no-border-collapse": "",
              items: _vm.arrayFicha,
              fields: _vm.fields,
            },
            scopedSlots: _vm._u([
              {
                key: "cell(p_sexo)",
                fn: function (data) {
                  return [
                    _vm._v(
                      "\n                " +
                        _vm._s(
                          data.item.p_sexo === "M"
                            ? "Masculino"
                            : data.item.p_sexo === "F"
                            ? "Femenino"
                            : "Otro"
                        ) +
                        "\n            "
                    ),
                  ]
                },
              },
              {
                key: "cell(p_activo)",
                fn: function (data) {
                  return [
                    _c(
                      "b-badge",
                      { attrs: { variant: _vm.estado[1][data.item.p_activo] } },
                      [
                        _vm._v(
                          "\n                    " +
                            _vm._s(_vm.estado[0][data.item.p_activo]) +
                            "\n                "
                        ),
                      ]
                    ),
                  ]
                },
              },
              {
                key: "cell(opcion)",
                fn: function (data) {
                  return [
                    _c("feather-icon", {
                      staticClass: "icon-action text-primary mr-2",
                      class: { disabled: data.item.p_activo === 0 },
                      attrs: { icon: "EditIcon" },
                      on: {
                        click: function ($event) {
                          data.item.p_activo ? _vm.editar(data.item) : null
                        },
                      },
                    }),
                    _vm._v(" "),
                    _c("feather-icon", {
                      staticClass: "icon-action text-danger mr-2",
                      class: { disabled: data.item.p_activo === 0 },
                      attrs: { icon: "XCircleIcon" },
                      on: {
                        click: function ($event) {
                          data.item.p_activo
                            ? _vm.abrirModalAnulacion(data.item)
                            : null
                        },
                      },
                    }),
                    _vm._v(" "),
                    _c("feather-icon", {
                      staticClass: "icon-action text-secondary",
                      class: { disabled: data.item.p_activo === 0 },
                      attrs: { icon: "PrinterIcon" },
                      on: {
                        click: function ($event) {
                          data.item.p_activo
                            ? _vm.imprimirFicha(data.item)
                            : null
                        },
                      },
                    }),
                  ]
                },
              },
            ]),
          }),
          _vm._v(" "),
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { cols: "2" } },
                [
                  _c(
                    "b-form-group",
                    { staticClass: "mb-0" },
                    [
                      _c(
                        "label",
                        { staticClass: "d-inline-block text-sm-left mr-50" },
                        [_vm._v("Por página")]
                      ),
                      _vm._v(" "),
                      _c("b-form-select", {
                        staticClass: "w-50",
                        attrs: { size: "sm", options: _vm.pageOptions },
                        on: {
                          input: function ($event) {
                            return _vm.listarFicha()
                          },
                        },
                        model: {
                          value: _vm.perPage,
                          callback: function ($$v) {
                            _vm.perPage = $$v
                          },
                          expression: "perPage",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-col", { attrs: { cols: "10" } }, [
                _c(
                  "span",
                  { staticStyle: { float: "right" } },
                  [
                    _c("b-pagination", {
                      staticClass: "my-0",
                      attrs: {
                        "total-rows": _vm.totalRows,
                        "per-page": _vm.perPage,
                        align: "center",
                        size: "sm",
                      },
                      model: {
                        value: _vm.currentPage,
                        callback: function ($$v) {
                          _vm.currentPage = $$v
                        },
                        expression: "currentPage",
                      },
                    }),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: {
            "hide-footer": "",
            centered: "",
            title: "ANULAR FICHA",
            size: "md",
          },
          model: {
            value: _vm.modalAnulacion,
            callback: function ($$v) {
              _vm.modalAnulacion = $$v
            },
            expression: "modalAnulacion",
          },
        },
        [
          _c(
            "b-button",
            {
              staticClass: "float-left",
              attrs: { variant: "outline-danger" },
              on: {
                click: function ($event) {
                  _vm.modalAnulacion = false
                },
              },
            },
            [_vm._v(" Cancelar ")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-right",
              attrs: { variant: "outline-success" },
              on: {
                click: function ($event) {
                  return _vm.anular()
                },
              },
            },
            [_vm._v(" Aceptar ")]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/Farmacia/ListaFP.vue":
/*!*****************************************************!*\
  !*** ./resources/js/src/views/Farmacia/ListaFP.vue ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ListaFP_vue_vue_type_template_id_08193c78___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ListaFP.vue?vue&type=template&id=08193c78& */ "./resources/js/src/views/Farmacia/ListaFP.vue?vue&type=template&id=08193c78&");
/* harmony import */ var _ListaFP_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ListaFP.vue?vue&type=script&lang=js& */ "./resources/js/src/views/Farmacia/ListaFP.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ListaFP_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ListaFP_vue_vue_type_template_id_08193c78___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ListaFP_vue_vue_type_template_id_08193c78___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/Farmacia/ListaFP.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/Farmacia/ListaFP.vue?vue&type=script&lang=js&":
/*!******************************************************************************!*\
  !*** ./resources/js/src/views/Farmacia/ListaFP.vue?vue&type=script&lang=js& ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaFP_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./ListaFP.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/ListaFP.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaFP_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/Farmacia/ListaFP.vue?vue&type=template&id=08193c78&":
/*!************************************************************************************!*\
  !*** ./resources/js/src/views/Farmacia/ListaFP.vue?vue&type=template&id=08193c78& ***!
  \************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaFP_vue_vue_type_template_id_08193c78___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./ListaFP.vue?vue&type=template&id=08193c78& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/ListaFP.vue?vue&type=template&id=08193c78&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaFP_vue_vue_type_template_id_08193c78___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ListaFP_vue_vue_type_template_id_08193c78___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);