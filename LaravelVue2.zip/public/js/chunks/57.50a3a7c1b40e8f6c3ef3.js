(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[57],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/RolesPermisos/Roles.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/RolesPermisos/Roles.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      // variables para el modal
      fieldsMenu: ['#', {
        key: 'descripcion',
        label: 'menú'
      }, {
        key: 'sm_descripcion',
        label: 'sub menú'
      }, {
        key: 'opcion',
        label: 'opción',
        "class": 'text-center'
      }],
      arrayIDMenu: [],
      btnShow: false,
      arrayMenu: [],
      show: false,
      header: '',
      // variables para la tabla
      arrayRoles: [],
      fields: ['#', {
        key: 'tu_nombre',
        label: 'Rol'
      }, {
        key: 'tu_activo',
        label: 'estado',
        "class": 'text-center'
      }, {
        key: 'opcion',
        label: 'acción',
        "class": 'text-center'
      }],
      estado: [{
        0: 'INACTIVO',
        1: 'ACTIVO'
      }, {
        0: 'light-danger',
        1: 'light-success'
      }],
      // variables para el guardado y actualizacion de datos
      id: 0,
      rol: '',
      sub_menu: 'Inicio',
      arraySubMenu: [],
      overlayTable: false,
      overlayStorage: false
    };
  },
  mounted: function mounted() {
    this.listarRoles();
    this.listarMenu();
    this.listarSubMenu();
  },
  methods: {
    guardarRol: function guardarRol() {
      var _this = this;

      this.overlayStorage = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/guardarRol', {
        'nombre': this.rol,
        'inicio': this.sub_menu,
        'arrayMenu': this.arrayIDMenu
      }).then(function (res) {
        _this.arrayIDMenu = [];
        _this.show = false;

        _this.listarRoles();
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this.overlayStorage = false;
      });
    },
    editarRol: function editarRol() {
      var _this2 = this;

      this.overlayStorage = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/editarRol', {
        'id': this.id,
        'nombre': this.rol,
        'inicio': this.sub_menu,
        'arrayMenu': this.arrayIDMenu
      }).then(function (res) {
        _this2.arrayIDMenu = [];
        _this2.show = false;

        _this2.listarRoles();
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this2.overlayStorage = false;
      });
    },
    cambiarEstado: function cambiarEstado(objeto) {
      var _this3 = this;

      axios.post('/cambiarEstadoTipoUsuario', {
        'tipo_usuario': objeto.id_tipo_usuario,
        'estado': objeto.tu_activo
      }).then(function (res) {
        _this3.listarRoles();
      })["catch"](function (err) {
        console.log(err.response);
      });
    },
    abrirModal: function abrirModal(objeto, tipo) {
      console.log(objeto);
      this.header = tipo ? 'EDITAR ROL' : 'NUEVO ROL';
      this.btnShow = tipo ? false : true;

      if (objeto != null) {
        this.id = objeto.id_tipo_usuario;
        this.rol = objeto.tu_nombre;
        this.sub_menu = objeto.tu_inicio;
        this.obtenerMenuID(objeto.id_tipo_usuario);
      } else {
        this.arrayIDMenu = [];
        this.id = 0;
        this.rol = '';
        this.sub_menu = 'Inicio';
      }

      this.show = true;
    },
    obtenerMenuID: function obtenerMenuID(tipo_usuario) {
      var _this4 = this;

      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarMenuId?id=' + tipo_usuario).then(function (res) {
        var filtroMenu = [];

        for (var index = 0; index < res.data.length; index++) {
          filtroMenu.push(res.data[index].id_sub_menu);
        }

        _this4.arrayIDMenu = filtroMenu;
      })["catch"](function (err) {
        console.log(err);
      });
    },
    listarRoles: function listarRoles() {
      var _this5 = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarRoles').then(function (res) {
        _this5.arrayRoles = res.data;
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this5.overlayTable = false;
      });
    },
    listarMenu: function listarMenu() {
      var _this6 = this;

      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarMenu').then(function (res) {
        _this6.arrayMenu = res.data;
      })["catch"](function (err) {
        console.log(err);
      });
    },
    listarSubMenu: function listarSubMenu() {
      var _this7 = this;

      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarSubMenu').then(function (res) {
        for (var index = 0; index < res.data.length; index++) {
          _this7.arraySubMenu.push({
            value: res.data[index].sm_ruta,
            text: res.data[index].descripcion + ' | ' + res.data[index].sm_descripcion
          });
        }
      })["catch"](function (err) {
        console.log(err);
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/RolesPermisos/Roles.vue?vue&type=template&id=615279a2&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/RolesPermisos/Roles.vue?vue&type=template&id=615279a2& ***!
  \*********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-card",
        [
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayTable,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c(
            "b-button",
            {
              attrs: { variant: "outline-info" },
              on: {
                click: function ($event) {
                  return _vm.abrirModal(null, false)
                },
              },
            },
            [
              _c("feather-icon", {
                staticClass: "mr-50",
                attrs: { icon: "UsersIcon" },
              }),
              _vm._v("\n            Nuevo Rol\n        "),
            ],
            1
          ),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c("b-table", {
            attrs: {
              hover: "",
              striped: "",
              responsive: "",
              bordered: "",
              small: "",
              "no-border-collapse": "",
              items: _vm.arrayRoles,
              fields: _vm.fields,
            },
            scopedSlots: _vm._u([
              {
                key: "cell(#)",
                fn: function (data) {
                  return [
                    _c("div", { staticStyle: { "text-align": "right" } }, [
                      _vm._v(
                        "\n                    " +
                          _vm._s(data.index + 1) +
                          "\n                "
                      ),
                    ]),
                  ]
                },
              },
              {
                key: "cell(tu_nombre)",
                fn: function (data) {
                  return [
                    _vm._v(
                      "\n                " +
                        _vm._s(data.item.tu_nombre) +
                        "\n            "
                    ),
                  ]
                },
              },
              {
                key: "cell(tu_activo)",
                fn: function (data) {
                  return [
                    _c(
                      "div",
                      { staticStyle: { "text-align": "center" } },
                      [
                        _c(
                          "b-badge",
                          {
                            attrs: {
                              variant: _vm.estado[1][data.item.tu_activo],
                            },
                          },
                          [
                            _vm._v(
                              "\n                        " +
                                _vm._s(_vm.estado[0][data.item.tu_activo]) +
                                "\n                    "
                            ),
                          ]
                        ),
                      ],
                      1
                    ),
                  ]
                },
              },
              {
                key: "cell(opcion)",
                fn: function (data) {
                  return [
                    _c(
                      "div",
                      { staticStyle: { "text-align": "center" } },
                      [
                        data.item.tu_activo
                          ? _c(
                              "b-button",
                              {
                                staticClass:
                                  "btn-icon rounded-circle text-center",
                                attrs: {
                                  variant: "flat-danger",
                                  title: "desactivar",
                                },
                                on: {
                                  click: function ($event) {
                                    return _vm.cambiarEstado(data.item)
                                  },
                                },
                              },
                              [
                                _c("feather-icon", {
                                  attrs: { icon: "LockIcon" },
                                }),
                              ],
                              1
                            )
                          : _c(
                              "b-button",
                              {
                                staticClass:
                                  "btn-icon rounded-circle text-center",
                                attrs: {
                                  variant: "flat-success",
                                  title: "activar",
                                },
                                on: {
                                  click: function ($event) {
                                    return _vm.cambiarEstado(data.item)
                                  },
                                },
                              },
                              [
                                _c("feather-icon", {
                                  attrs: { icon: "UnlockIcon" },
                                }),
                              ],
                              1
                            ),
                        _vm._v(" "),
                        _c(
                          "b-button",
                          {
                            staticClass: "btn-icon rounded-circle text-center",
                            attrs: { variant: "flat-info", title: "editar" },
                            on: {
                              click: function ($event) {
                                return _vm.abrirModal(data.item, true)
                              },
                            },
                          },
                          [_c("feather-icon", { attrs: { icon: "EditIcon" } })],
                          1
                        ),
                      ],
                      1
                    ),
                  ]
                },
              },
            ]),
          }),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: { "hide-footer": "", centered: "", title: _vm.header },
          model: {
            value: _vm.show,
            callback: function ($$v) {
              _vm.show = $$v
            },
            expression: "show",
          },
        },
        [
          _c(
            "b-form-group",
            [
              _c("label", [_vm._v(" Rol ")]),
              _vm._v(" "),
              _c("b-form-input", {
                attrs: {
                  type: "text",
                  placeholder: "Rol",
                  state: _vm.rol != "",
                },
                model: {
                  value: _vm.rol,
                  callback: function ($$v) {
                    _vm.rol = $$v
                  },
                  expression: "rol",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-form-group",
            [
              _c("label", [_vm._v(" Pantalla de Inicio ")]),
              _vm._v(" "),
              _c("b-form-select", {
                attrs: { options: _vm.arraySubMenu, state: true },
                model: {
                  value: _vm.sub_menu,
                  callback: function ($$v) {
                    _vm.sub_menu = $$v
                  },
                  expression: "sub_menu",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayStorage,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c("label", { staticClass: "mb-0" }, [
            _c("b", [_vm._v(" Lista Menú ")]),
          ]),
          _vm._v(" "),
          _c("b-table", {
            attrs: {
              hover: "",
              striped: "",
              responsive: "",
              bordered: "",
              small: "",
              "sticky-header": "",
              "no-border-collapse": "",
              items: _vm.arrayMenu,
              fields: _vm.fieldsMenu,
            },
            scopedSlots: _vm._u([
              {
                key: "cell(#)",
                fn: function (data) {
                  return [
                    _c("div", { staticStyle: { "text-align": "right" } }, [
                      _vm._v(
                        "\n                    " +
                          _vm._s(data.index + 1) +
                          "\n                "
                      ),
                    ]),
                  ]
                },
              },
              {
                key: "cell(descripcion)",
                fn: function (data) {
                  return [
                    _vm._v(
                      "\n                " +
                        _vm._s(data.item.descripcion) +
                        "\n            "
                    ),
                  ]
                },
              },
              {
                key: "cell(sm_descripcion)",
                fn: function (data) {
                  return [
                    _vm._v(
                      "\n                " +
                        _vm._s(data.item.sm_descripcion) +
                        "\n            "
                    ),
                  ]
                },
              },
              {
                key: "cell(opcion)",
                fn: function (data) {
                  return [
                    _c(
                      "div",
                      { staticStyle: { "text-align": "center" } },
                      [
                        _c("b-form-checkbox", {
                          staticClass: "custom-control-info",
                          attrs: { value: data.item.id_sub_menu },
                          model: {
                            value: _vm.arrayIDMenu,
                            callback: function ($$v) {
                              _vm.arrayIDMenu = $$v
                            },
                            expression: "arrayIDMenu",
                          },
                        }),
                      ],
                      1
                    ),
                  ]
                },
              },
            ]),
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-left",
              attrs: { variant: "outline-danger" },
              on: {
                click: function ($event) {
                  _vm.show = false
                },
              },
            },
            [_vm._v("\n            Cerrar\n        ")]
          ),
          _vm._v(" "),
          _vm.btnShow
            ? _c(
                "b-button",
                {
                  staticClass: "float-right",
                  attrs: { variant: "outline-success" },
                  on: {
                    click: function ($event) {
                      return _vm.guardarRol()
                    },
                  },
                },
                [_vm._v("\n            Guardar\n        ")]
              )
            : _c(
                "b-button",
                {
                  staticClass: "float-right",
                  attrs: { variant: "outline-success" },
                  on: {
                    click: function ($event) {
                      return _vm.editarRol()
                    },
                  },
                },
                [_vm._v("\n            Editar\n        ")]
              ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/RolesPermisos/Roles.vue":
/*!********************************************************!*\
  !*** ./resources/js/src/views/RolesPermisos/Roles.vue ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Roles_vue_vue_type_template_id_615279a2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Roles.vue?vue&type=template&id=615279a2& */ "./resources/js/src/views/RolesPermisos/Roles.vue?vue&type=template&id=615279a2&");
/* harmony import */ var _Roles_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Roles.vue?vue&type=script&lang=js& */ "./resources/js/src/views/RolesPermisos/Roles.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Roles_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Roles_vue_vue_type_template_id_615279a2___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Roles_vue_vue_type_template_id_615279a2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/RolesPermisos/Roles.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/RolesPermisos/Roles.vue?vue&type=script&lang=js&":
/*!*********************************************************************************!*\
  !*** ./resources/js/src/views/RolesPermisos/Roles.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Roles_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Roles.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/RolesPermisos/Roles.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Roles_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/RolesPermisos/Roles.vue?vue&type=template&id=615279a2&":
/*!***************************************************************************************!*\
  !*** ./resources/js/src/views/RolesPermisos/Roles.vue?vue&type=template&id=615279a2& ***!
  \***************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Roles_vue_vue_type_template_id_615279a2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Roles.vue?vue&type=template&id=615279a2& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/RolesPermisos/Roles.vue?vue&type=template&id=615279a2&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Roles_vue_vue_type_template_id_615279a2___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Roles_vue_vue_type_template_id_615279a2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);