(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[33],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ControlReses/RepesadoEditar.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ControlReses/RepesadoEditar.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      // paginación
      pageOptions: [50, 100, 200, 500],
      currentPage: 1,
      totalRows: 1,
      perPage: 50,
      overlayTable: false,
      arrayRepesado: [],
      fields: [{
        key: 'codDocAlm',
        label: 'cod. doc.'
      }, {
        key: 'nombreDoc',
        label: 'tipo doc.'
      }, {
        key: 'nombre',
        label: 'suc. orig.'
      }, {
        key: 'fecha',
        label: 'fecha'
      }, {
        key: 'codCli',
        label: 'cliente'
      }, {
        key: 'va_cod_res',
        label: 'res'
      }, {
        key: 'codCorrelativoRes',
        label: 'nro res'
      }, {
        key: 'codParFri',
        label: 'cod. parte'
      }, {
        key: 'migracion',
        label: 'tra4'
      }, {
        key: 'opcion',
        label: ''
      }],
      overlayRes: false,
      modalRes: false,
      arrayReses: [{
        value: 1,
        text: '1'
      }, {
        value: 2,
        text: '2'
      }, {
        value: 3,
        text: '3'
      }, {
        value: 4,
        text: '4'
      }],
      nro_res: 1,
      buscar: '',
      desde: null,
      hasta: null,
      id: 0
    };
  },
  mounted: function mounted() {
    this.desde = this.$moment().startOf('month').format('YYYY-MM-DD');
    this.hasta = this.$moment().format('YYYY-MM-DD');
    this.listarRepesado();
  },
  watch: {
    currentPage: function currentPage(newPage) {
      this.currentPage = newPage;
      this.listarRepesado();
    }
  },
  methods: {
    abrirModal: function abrirModal(item) {
      this.id = item.codRep;
      this.nro_res = item.codCorrelativoRes;
      this.modalRes = true;
    },
    listarRepesado: function listarRepesado() {
      var _this = this;

      this.overlayTable = true;
      this.arrayRepesado = [];
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarRepesado?perPage=' + this.perPage + '&page=' + this.currentPage + '&buscar=' + this.buscar + '&fecha_inicio=' + this.desde + '&fecha_fin=' + this.hasta).then(function (res) {
        _this.arrayRepesado = res.data.data;
        _this.totalRows = res.data.total;
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this.overlayTable = false;
      });
    },
    guardarRes: function guardarRes() {
      var _this2 = this;

      this.overlayRes = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/editarResRepesado', {
        'id': this.id,
        'res': this.nro_res
      }).then(function (res) {
        _this2.listarRepesado();

        _this2.modalRes = false;
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this2.overlayRes = false;
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ControlReses/RepesadoEditar.vue?vue&type=template&id=4a2e19a0&":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ControlReses/RepesadoEditar.vue?vue&type=template&id=4a2e19a0& ***!
  \*****************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-card",
        [
          _c(
            "b-row",
            [
              _c("b-col", { attrs: { md: "12" } }, [
                _c(
                  "div",
                  { staticClass: "d-flex align-items-center float-right" },
                  [
                    _c("b-form-input", {
                      attrs: { placeholder: "Buscar...", state: true },
                      model: {
                        value: _vm.buscar,
                        callback: function ($$v) {
                          _vm.buscar = $$v
                        },
                        expression: "buscar",
                      },
                    }),
                    _vm._v(" "),
                    _c("b-form-datepicker", {
                      staticClass: "ml-2",
                      attrs: {
                        "date-format-options": {
                          year: "numeric",
                          month: "numeric",
                          day: "numeric",
                        },
                        "selected-variant": "primary",
                        "button-variant": "primary",
                        state: true,
                      },
                      model: {
                        value: _vm.desde,
                        callback: function ($$v) {
                          _vm.desde = $$v
                        },
                        expression: "desde",
                      },
                    }),
                    _vm._v(" "),
                    _c("b-form-datepicker", {
                      staticClass: "mx-2",
                      attrs: {
                        "date-format-options": {
                          year: "numeric",
                          month: "numeric",
                          day: "numeric",
                        },
                        "selected-variant": "primary",
                        "button-variant": "primary",
                        state: true,
                      },
                      model: {
                        value: _vm.hasta,
                        callback: function ($$v) {
                          _vm.hasta = $$v
                        },
                        expression: "hasta",
                      },
                    }),
                    _vm._v(" "),
                    _c(
                      "b-button",
                      {
                        attrs: { variant: "outline-success" },
                        on: {
                          click: function ($event) {
                            return _vm.listarRepesado()
                          },
                        },
                      },
                      [
                        _c("feather-icon", {
                          attrs: { icon: "SearchIcon", size: "16" },
                        }),
                      ],
                      1
                    ),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-card",
        [
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayTable,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("b-table", {
            attrs: {
              hover: "",
              striped: "",
              responsive: "",
              bordered: "",
              small: "",
              "no-border-collapse": "",
              items: _vm.arrayRepesado,
              fields: _vm.fields,
            },
            scopedSlots: _vm._u([
              {
                key: "cell(opcion)",
                fn: function (data) {
                  return [
                    _c(
                      "div",
                      { staticStyle: { "text-align": "center" } },
                      [
                        _c(
                          "b-button",
                          {
                            staticClass: "btn-icon rounded-circle text-center",
                            attrs: { variant: "flat-info", title: "editar" },
                            on: {
                              click: function ($event) {
                                return _vm.abrirModal(data.item)
                              },
                            },
                          },
                          [_c("feather-icon", { attrs: { icon: "EditIcon" } })],
                          1
                        ),
                      ],
                      1
                    ),
                  ]
                },
              },
            ]),
          }),
          _vm._v(" "),
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { cols: "2" } },
                [
                  _c(
                    "b-form-group",
                    { staticClass: "mb-0" },
                    [
                      _c(
                        "label",
                        { staticClass: "d-inline-block text-sm-left mr-50" },
                        [_vm._v("Por página")]
                      ),
                      _vm._v(" "),
                      _c("b-form-select", {
                        staticClass: "w-50",
                        attrs: { size: "sm", options: _vm.pageOptions },
                        on: {
                          input: function ($event) {
                            return _vm.listarRepesado()
                          },
                        },
                        model: {
                          value: _vm.perPage,
                          callback: function ($$v) {
                            _vm.perPage = $$v
                          },
                          expression: "perPage",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-col", { attrs: { cols: "10" } }, [
                _c(
                  "span",
                  { staticStyle: { float: "right" } },
                  [
                    _c("b-pagination", {
                      staticClass: "my-0",
                      attrs: {
                        "total-rows": _vm.totalRows,
                        "per-page": _vm.perPage,
                        align: "center",
                        size: "sm",
                      },
                      model: {
                        value: _vm.currentPage,
                        callback: function ($$v) {
                          _vm.currentPage = $$v
                        },
                        expression: "currentPage",
                      },
                    }),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          directives: [
            {
              name: "b-modal",
              rawName: "v-b-modal.modal-xs",
              modifiers: { "modal-xs": true },
            },
          ],
          attrs: {
            centered: "",
            title: "EDITAR NRO RES",
            "hide-footer": "",
            size: "xs",
          },
          model: {
            value: _vm.modalRes,
            callback: function ($$v) {
              _vm.modalRes = $$v
            },
            expression: "modalRes",
          },
        },
        [
          _c(
            "b-form-group",
            [
              _c("label", [_vm._v(" Nro. Res ")]),
              _vm._v(" "),
              _c("b-form-select", {
                attrs: { options: _vm.arrayReses, state: true },
                model: {
                  value: _vm.nro_res,
                  callback: function ($$v) {
                    _vm.nro_res = $$v
                  },
                  expression: "nro_res",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayRes,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-left",
              attrs: { variant: "outline-danger" },
              on: {
                click: function ($event) {
                  _vm.modalRes = false
                },
              },
            },
            [_vm._v(" Cancelar ")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-right",
              attrs: { variant: "outline-success" },
              on: {
                click: function ($event) {
                  return _vm.guardarRes()
                },
              },
            },
            [_vm._v(" Guardar ")]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/ControlReses/RepesadoEditar.vue":
/*!****************************************************************!*\
  !*** ./resources/js/src/views/ControlReses/RepesadoEditar.vue ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _RepesadoEditar_vue_vue_type_template_id_4a2e19a0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./RepesadoEditar.vue?vue&type=template&id=4a2e19a0& */ "./resources/js/src/views/ControlReses/RepesadoEditar.vue?vue&type=template&id=4a2e19a0&");
/* harmony import */ var _RepesadoEditar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./RepesadoEditar.vue?vue&type=script&lang=js& */ "./resources/js/src/views/ControlReses/RepesadoEditar.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _RepesadoEditar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _RepesadoEditar_vue_vue_type_template_id_4a2e19a0___WEBPACK_IMPORTED_MODULE_0__["render"],
  _RepesadoEditar_vue_vue_type_template_id_4a2e19a0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ControlReses/RepesadoEditar.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ControlReses/RepesadoEditar.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/src/views/ControlReses/RepesadoEditar.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RepesadoEditar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./RepesadoEditar.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ControlReses/RepesadoEditar.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RepesadoEditar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/ControlReses/RepesadoEditar.vue?vue&type=template&id=4a2e19a0&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/ControlReses/RepesadoEditar.vue?vue&type=template&id=4a2e19a0& ***!
  \***********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_RepesadoEditar_vue_vue_type_template_id_4a2e19a0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./RepesadoEditar.vue?vue&type=template&id=4a2e19a0& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ControlReses/RepesadoEditar.vue?vue&type=template&id=4a2e19a0&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_RepesadoEditar_vue_vue_type_template_id_4a2e19a0___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_RepesadoEditar_vue_vue_type_template_id_4a2e19a0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);