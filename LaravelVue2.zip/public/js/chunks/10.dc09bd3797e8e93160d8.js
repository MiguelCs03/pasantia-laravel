(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[10],{

/***/ "./resources/js/src/views/RolesPermisos/Roles.vue":
/*!********************************************************!*\
  !*** ./resources/js/src/views/RolesPermisos/Roles.vue ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, exports) {

throw new Error("Module build failed (from ./node_modules/vue-loader/lib/index.js):\nError: ENOENT: no such file or directory, open 'D:\\PROYECTOS PROPIOS\\WEB_MODULOS\\resources\\js\\src\\views\\RolesPermisos\\Roles.vue'");

/***/ })

}]);