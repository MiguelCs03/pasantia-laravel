(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[50],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ParametrosTR4/CodigoParte.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ParametrosTR4/CodigoParte.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      // paginación
      pageOptions: [50, 100, 200, 500],
      currentPage: 1,
      totalRows: 1,
      perPage: 50,
      arrayPartes: [],
      fields: [{
        key: 'codParFri',
        label: 'código'
      }, {
        key: 'nombre',
        label: 'código parte'
      }, {
        key: 'max',
        label: 'peso máximo'
      }, {
        key: 'min',
        label: 'peso mínimo'
      }, {
        key: 'activo',
        label: 'estado',
        "class": 'text-center'
      }, {
        key: 'opcion',
        label: 'opción',
        "class": 'text-center'
      }],
      estado: [{
        0: 'INACTIVO',
        1: 'ACTIVO'
      }, {
        0: 'light-danger',
        1: 'light-success'
      }],
      overlayTable: false,
      buscar: '',
      id: 0,
      min: '',
      max: '',
      modalParte: false,
      overlayStorage: false
    };
  },
  mounted: function mounted() {
    this.listarCodigoPartes();
  },
  watch: {
    currentPage: function currentPage(newPage) {
      this.currentPage = newPage;
      this.listarCodigoPartes();
    }
  },
  methods: {
    abrirModal: function abrirModal(item) {
      this.id = item.codParFri;
      this.min = item.min;
      this.max = item.max;
      this.modalParte = true;
    },
    listarCodigoPartes: function listarCodigoPartes() {
      var _this = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarCodigoPartes?perPage=' + this.perPage + '&page=' + this.currentPage + '&buscar=' + this.buscar).then(function (res) {
        _this.arrayPartes = res.data.data;
        _this.totalRows = res.data.total;
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this.overlayTable = false;
      });
    },
    editarCodigoPartes: function editarCodigoPartes() {
      var _this2 = this;

      if (this.min < this.max) {
        this.overlayStorage = true;
        axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
        this.axios.post('/editarCodigoPartes', {
          'id': this.id,
          'min': this.min,
          'max': this.max
        }).then(function (res) {
          _this2.modalParte = false;

          _this2.listarCodigoPartes();

          _this2.pop_up('Éxito', 'Guardar Correctamente', 'success');
        })["catch"](function (err) {
          console.log(err);
          if (err.response.status == 422) _this2.pop_up('Error', 'LLenar los campos obligatorios', 'error');else _this2.pop_up('Error', 'Error al Guardar', 'error');
        })["finally"](function () {
          _this2.overlayStorage = false;
        });
      } else {
        this.pop_up('Error', 'El Mínimo no debe ser mayor al Máximo', 'error');
      }
    },
    pop_up: function pop_up(title, text, icon) {
      this.$swal({
        title: title,
        text: text,
        icon: icon,
        showConfirmButton: false,
        timer: 2000,
        customClass: {
          confirmButton: 'btn btn-primary'
        },
        buttonsStyling: false
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ParametrosTR4/CodigoParte.vue?vue&type=template&id=386f0c2c&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ParametrosTR4/CodigoParte.vue?vue&type=template&id=386f0c2c& ***!
  \***************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-card",
        [
          _c(
            "b-row",
            [
              _c("b-col", { attrs: { md: "8" } }),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "4" } },
                [
                  _c(
                    "b-input-group",
                    [
                      _c("b-form-input", {
                        attrs: { placeholder: "Buscar...", state: true },
                        model: {
                          value: _vm.buscar,
                          callback: function ($$v) {
                            _vm.buscar = $$v
                          },
                          expression: "buscar",
                        },
                      }),
                      _vm._v(" "),
                      _c(
                        "b-input-group-append",
                        [
                          _c(
                            "b-button",
                            {
                              attrs: { variant: "outline-success" },
                              on: {
                                click: function ($event) {
                                  return _vm.listarCodigoPartes()
                                },
                              },
                            },
                            [_vm._v(" Buscar ")]
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayTable,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c("b-table", {
            attrs: {
              hover: "",
              striped: "",
              responsive: "",
              bordered: "",
              small: "",
              "no-border-collapse": "",
              items: _vm.arrayPartes,
              fields: _vm.fields,
            },
            scopedSlots: _vm._u([
              {
                key: "cell(activo)",
                fn: function (data) {
                  return [
                    _c(
                      "b-badge",
                      { attrs: { variant: _vm.estado[1][data.item.activo] } },
                      [
                        _vm._v(
                          "\n                    " +
                            _vm._s(_vm.estado[0][data.item.activo]) +
                            "\n                "
                        ),
                      ]
                    ),
                  ]
                },
              },
              {
                key: "cell(opcion)",
                fn: function (data) {
                  return [
                    _c(
                      "b-button",
                      {
                        staticClass: "btn-icon rounded-circle text-center",
                        attrs: { variant: "flat-info", title: "'editar'" },
                        on: {
                          click: function ($event) {
                            return _vm.abrirModal(data.item)
                          },
                        },
                      },
                      [_c("feather-icon", { attrs: { icon: "EditIcon" } })],
                      1
                    ),
                  ]
                },
              },
            ]),
          }),
          _vm._v(" "),
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { cols: "2" } },
                [
                  _c(
                    "b-form-group",
                    { staticClass: "mb-0" },
                    [
                      _c(
                        "label",
                        { staticClass: "d-inline-block text-sm-left mr-50" },
                        [_vm._v("Por página")]
                      ),
                      _vm._v(" "),
                      _c("b-form-select", {
                        staticClass: "w-50",
                        attrs: { size: "sm", options: _vm.pageOptions },
                        on: {
                          input: function ($event) {
                            return _vm.listarCodigoPartes()
                          },
                        },
                        model: {
                          value: _vm.perPage,
                          callback: function ($$v) {
                            _vm.perPage = $$v
                          },
                          expression: "perPage",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-col", { attrs: { cols: "10" } }, [
                _c(
                  "span",
                  { staticStyle: { float: "right" } },
                  [
                    _c("b-pagination", {
                      staticClass: "my-0",
                      attrs: {
                        "total-rows": _vm.totalRows,
                        "per-page": _vm.perPage,
                        align: "center",
                        size: "sm",
                      },
                      model: {
                        value: _vm.currentPage,
                        callback: function ($$v) {
                          _vm.currentPage = $$v
                        },
                        expression: "currentPage",
                      },
                    }),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: { "hide-footer": "", centered: "", title: "EDITAR VALORES" },
          model: {
            value: _vm.modalParte,
            callback: function ($$v) {
              _vm.modalParte = $$v
            },
            expression: "modalParte",
          },
        },
        [
          _c(
            "b-form-group",
            [
              _c("label", [_vm._v(" Mínimo ")]),
              _vm._v(" "),
              _c("b-form-input", {
                attrs: { placeholder: "Mínimo", state: _vm.min != "" },
                model: {
                  value: _vm.min,
                  callback: function ($$v) {
                    _vm.min = $$v
                  },
                  expression: "min",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-form-group",
            [
              _c("label", [_vm._v(" Máximo ")]),
              _vm._v(" "),
              _c("b-form-input", {
                attrs: { placeholder: "Máximo", state: _vm.max != "" },
                model: {
                  value: _vm.max,
                  callback: function ($$v) {
                    _vm.max = $$v
                  },
                  expression: "max",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayStorage,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-left",
              attrs: { variant: "outline-danger" },
              on: {
                click: function ($event) {
                  _vm.modalParte = false
                },
              },
            },
            [_vm._v(" Cancelar ")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-right",
              attrs: { variant: "outline-success" },
              on: {
                click: function ($event) {
                  return _vm.editarCodigoPartes()
                },
              },
            },
            [_vm._v(" Guardar ")]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/ParametrosTR4/CodigoParte.vue":
/*!**************************************************************!*\
  !*** ./resources/js/src/views/ParametrosTR4/CodigoParte.vue ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CodigoParte_vue_vue_type_template_id_386f0c2c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CodigoParte.vue?vue&type=template&id=386f0c2c& */ "./resources/js/src/views/ParametrosTR4/CodigoParte.vue?vue&type=template&id=386f0c2c&");
/* harmony import */ var _CodigoParte_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CodigoParte.vue?vue&type=script&lang=js& */ "./resources/js/src/views/ParametrosTR4/CodigoParte.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CodigoParte_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CodigoParte_vue_vue_type_template_id_386f0c2c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CodigoParte_vue_vue_type_template_id_386f0c2c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ParametrosTR4/CodigoParte.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ParametrosTR4/CodigoParte.vue?vue&type=script&lang=js&":
/*!***************************************************************************************!*\
  !*** ./resources/js/src/views/ParametrosTR4/CodigoParte.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CodigoParte_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./CodigoParte.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ParametrosTR4/CodigoParte.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CodigoParte_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/ParametrosTR4/CodigoParte.vue?vue&type=template&id=386f0c2c&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/src/views/ParametrosTR4/CodigoParte.vue?vue&type=template&id=386f0c2c& ***!
  \*********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CodigoParte_vue_vue_type_template_id_386f0c2c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./CodigoParte.vue?vue&type=template&id=386f0c2c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ParametrosTR4/CodigoParte.vue?vue&type=template&id=386f0c2c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CodigoParte_vue_vue_type_template_id_386f0c2c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CodigoParte_vue_vue_type_template_id_386f0c2c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);