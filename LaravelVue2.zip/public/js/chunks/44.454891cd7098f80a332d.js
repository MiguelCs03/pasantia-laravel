(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[44],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/UnidadMedida.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Farmacia/UnidadMedida.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      overlayTable: false,
      arrayUnidades: [],
      fields: [{
        key: 'um_nombre',
        label: 'nombre medida'
      }, {
        key: 'um_abreviatura',
        label: 'abreviatura'
      }, {
        key: 'um_activo',
        label: 'estado',
        "class": 'text-center text-nowrap'
      }, {
        key: 'opcion',
        label: 'opción',
        "class": 'text-center text-nowrap'
      }],
      estado: [{
        0: 'INACTIVO',
        1: 'ACTIVO'
      }, {
        0: 'light-danger',
        1: 'light-success'
      }],
      abreviatura: '',
      nombre: '',
      id: 0
    };
  },
  mounted: function mounted() {
    this.listar();
  },
  methods: {
    listar: function listar() {
      var _this = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarUnidad').then(function (res) {
        _this.arrayUnidades = res.data;
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this.overlayTable = false;
      });
    },
    guardar: function guardar() {
      var _this2 = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/guardarUnidad', {
        'id': this.id,
        'nombre': this.nombre,
        'abreviatura': this.abreviatura
      }).then(function (res) {
        _this2.listar();

        _this2.cancelar();

        _this2.pop_up('Éxito', 'Guardado Correctamente', 'success');
      })["catch"](function (err) {
        console.log(err);
        _this2.overlayTable = false;
        if (err.response.status == 422) _this2.pop_up('Error', 'Debe llenar los campos obligatorios', 'error');else _this2.pop_up('Error', 'no se puedo Guardar', 'error');
      });
    },
    cargarDatos: function cargarDatos(item) {
      this.id = item.id_unidad_medida;
      this.nombre = item.um_nombre;
      this.abreviatura = item.um_abreviatura;
    },
    cancelar: function cancelar() {
      this.id = 0;
      this.nombre = '';
      this.abreviatura = '';
    },
    cambiarEstado: function cambiarEstado(item) {
      var _this3 = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/cambiarEstadoUnidad', {
        'id': item.id_unidad_medida,
        'estado': item.um_activo == 1 ? 0 : 1
      }).then(function (res) {
        _this3.listar();

        _this3.pop_up('Éxito', 'Guardado Correctamente', 'success');
      })["catch"](function (err) {
        console.log(err);
        _this3.overlayTable = false;
        if (err.response.status == 422) _this3.pop_up('Error', 'Debe llenar los campos obligatorios', 'error');else _this3.pop_up('Error', 'no se puedo Guardar', 'error');
      });
    },
    pop_up: function pop_up(title, text, icon) {
      this.$swal({
        title: title,
        text: text,
        icon: icon,
        showConfirmButton: false,
        timer: 2000,
        customClass: {
          confirmButton: 'btn btn-primary'
        },
        buttonsStyling: false
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/UnidadMedida.vue?vue&type=template&id=21429c14&":
/*!***********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Farmacia/UnidadMedida.vue?vue&type=template&id=21429c14& ***!
  \***********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-row",
        [
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayTable,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c(
            "b-col",
            { attrs: { md: "4" } },
            [
              _c(
                "b-card",
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Nombre ")]),
                      _vm._v(" "),
                      _c("b-form-input", {
                        attrs: {
                          placeholder: "Nombre",
                          state: _vm.nombre != "",
                        },
                        model: {
                          value: _vm.nombre,
                          callback: function ($$v) {
                            _vm.nombre = $$v
                          },
                          expression: "nombre",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Abreviatura ")]),
                      _vm._v(" "),
                      _c("b-form-input", {
                        attrs: {
                          placeholder: "Abreviatura",
                          state: _vm.abreviatura != "",
                        },
                        model: {
                          value: _vm.abreviatura,
                          callback: function ($$v) {
                            _vm.abreviatura = $$v
                          },
                          expression: "abreviatura",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("hr"),
                  _vm._v(" "),
                  _c(
                    "b-button",
                    {
                      attrs: { block: "", variant: "outline-success" },
                      on: {
                        click: function ($event) {
                          return _vm.guardar()
                        },
                      },
                    },
                    [_vm._v(" Guardar ")]
                  ),
                  _vm._v(" "),
                  _vm.nombre
                    ? _c(
                        "b-button",
                        {
                          attrs: { block: "", variant: "outline-danger" },
                          on: {
                            click: function ($event) {
                              return _vm.cancelar()
                            },
                          },
                        },
                        [_vm._v(" Cancelar ")]
                      )
                    : _vm._e(),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-col",
            { attrs: { md: "8" } },
            [
              _c(
                "b-card",
                [
                  _c("b-table", {
                    attrs: {
                      hover: "",
                      striped: "",
                      responsive: "",
                      bordered: "",
                      small: "",
                      "no-border-collapse": "",
                      items: _vm.arrayUnidades,
                      fields: _vm.fields,
                    },
                    scopedSlots: _vm._u([
                      {
                        key: "cell(um_activo)",
                        fn: function (data) {
                          return [
                            _c(
                              "b-badge",
                              {
                                attrs: {
                                  variant: _vm.estado[1][data.item.um_activo],
                                },
                              },
                              [
                                _vm._v(
                                  "\n                            " +
                                    _vm._s(_vm.estado[0][data.item.um_activo]) +
                                    "\n                        "
                                ),
                              ]
                            ),
                          ]
                        },
                      },
                      {
                        key: "cell(opcion)",
                        fn: function (data) {
                          return [
                            _c(
                              "b-button",
                              {
                                staticClass:
                                  "btn-icon rounded-circle text-center",
                                attrs: {
                                  variant: data.item.um_activo
                                    ? "flat-danger"
                                    : "flat-success",
                                  title: data.item.um_activo
                                    ? "desactivar"
                                    : "activar",
                                },
                                on: {
                                  click: function ($event) {
                                    return _vm.cambiarEstado(data.item)
                                  },
                                },
                              },
                              [
                                _c("feather-icon", {
                                  attrs: {
                                    icon: data.item.um_activo
                                      ? "LockIcon"
                                      : "UnlockIcon",
                                  },
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-button",
                              {
                                staticClass:
                                  "btn-icon rounded-circle text-center",
                                attrs: {
                                  variant: "flat-info",
                                  title: "editar",
                                },
                                on: {
                                  click: function ($event) {
                                    return _vm.cargarDatos(data.item)
                                  },
                                },
                              },
                              [
                                _c("feather-icon", {
                                  attrs: { icon: "EditIcon" },
                                }),
                              ],
                              1
                            ),
                          ]
                        },
                      },
                    ]),
                  }),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/Farmacia/UnidadMedida.vue":
/*!**********************************************************!*\
  !*** ./resources/js/src/views/Farmacia/UnidadMedida.vue ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _UnidadMedida_vue_vue_type_template_id_21429c14___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UnidadMedida.vue?vue&type=template&id=21429c14& */ "./resources/js/src/views/Farmacia/UnidadMedida.vue?vue&type=template&id=21429c14&");
/* harmony import */ var _UnidadMedida_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UnidadMedida.vue?vue&type=script&lang=js& */ "./resources/js/src/views/Farmacia/UnidadMedida.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _UnidadMedida_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _UnidadMedida_vue_vue_type_template_id_21429c14___WEBPACK_IMPORTED_MODULE_0__["render"],
  _UnidadMedida_vue_vue_type_template_id_21429c14___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/Farmacia/UnidadMedida.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/Farmacia/UnidadMedida.vue?vue&type=script&lang=js&":
/*!***********************************************************************************!*\
  !*** ./resources/js/src/views/Farmacia/UnidadMedida.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnidadMedida_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./UnidadMedida.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/UnidadMedida.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnidadMedida_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/Farmacia/UnidadMedida.vue?vue&type=template&id=21429c14&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/src/views/Farmacia/UnidadMedida.vue?vue&type=template&id=21429c14& ***!
  \*****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_UnidadMedida_vue_vue_type_template_id_21429c14___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./UnidadMedida.vue?vue&type=template&id=21429c14& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/UnidadMedida.vue?vue&type=template&id=21429c14&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_UnidadMedida_vue_vue_type_template_id_21429c14___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_UnidadMedida_vue_vue_type_template_id_21429c14___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);