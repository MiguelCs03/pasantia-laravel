(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[25],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/Medicamento.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Farmacia/Medicamento.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      // paginación
      pageOptions: [50, 100, 200, 500],
      currentPage: 1,
      totalRows: 1,
      perPage: 50,
      buscar: '',
      overlayTable: false,
      arrayMedicamentos: [],
      fields: [{
        key: 'med_nombre',
        label: 'medicamento'
      }, {
        key: 't_nombre',
        label: 'tipo'
      }, {
        key: 'c_nombre',
        label: 'categoría'
      }, {
        key: 'med_concentracion',
        label: 'concentración'
      }, {
        key: 'med_descripcion',
        label: 'descripción'
      }, {
        key: 'med_comentario',
        label: 'comentario'
      }, {
        key: 'med_activo',
        label: 'estado',
        "class": 'text-center text-nowrap'
      }, {
        key: 'opcion',
        label: 'opción',
        "class": 'text-center text-nowrap'
      }],
      estado: [{
        0: 'INACTIVO',
        1: 'ACTIVO'
      }, {
        0: 'light-danger',
        1: 'light-success'
      }],
      title: '',
      objMedicamento: {},
      modalStorage: false,
      overlayStorage: false,
      arrayFabricantes: [],
      arrayProveedores: [],
      arrayCategorias: [],
      arrayMedidas: [],
      arrayTipos: [],
      // variables para el perfil
      overlayImage: false,
      showImage: false,
      imageEnviar: '',
      image: '',
      src: ''
    };
  },
  mounted: function mounted() {
    this.listarMedicamento();
    this.listarSelectMedicamento();
  },
  computed: {
    imagen: function imagen() {
      return this.image;
    }
  },
  methods: {
    abrirModal: function abrirModal(item) {
      if (item != null) {
        this.title = 'EDITAR MEDICAMENTO';
        this.objMedicamento = {
          id: item.id_medicamento,
          tipo: item.id_tipo,
          venta: item.med_precio_venta,
          compra: item.med_precio_compra,
          nombre: item.med_nombre,
          lote: item.med_numero_lote,
          proveedor: item.id_proveedor,
          categoria: item.id_categoria,
          medida: item.id_unidad_medida,
          fabricante: item.id_fabricante,
          comentario: item.med_comentario,
          descripcion: item.med_descripcion,
          concentracion: item.med_concentracion,
          sanitario: item.med_registro_sanitario
        };
        this.verImagen(item);
      } else {
        this.title = 'NUEVO MEDICAMENTO';
        this.objMedicamento = {
          id: 0,
          venta: '',
          compra: ''
        };
        this.image = '';
        this.src = __webpack_require__(/*! @/assets/fridosa/medicamento.jpg */ "./resources/js/src/assets/fridosa/medicamento.jpg");
      }

      this.modalStorage = true;
    },
    verImagen: function verImagen(item) {
      var _this = this;

      var url = location.protocol + "//" + location.host + "/FotoMedicamento" + "/" + item.id_medicamento + ".jpg";
      this.verificarImagen(url).then(function () {
        console.log('La imagen existe');
        _this.image = url;
        _this.src = url;
      })["catch"](function () {
        console.log('La imagen no existe');
        _this.image = '';
        _this.src = __webpack_require__(/*! @/assets/fridosa/medicamento.jpg */ "./resources/js/src/assets/fridosa/medicamento.jpg");
      });
    },
    listarMedicamento: function listarMedicamento() {
      var _this2 = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarMedicamento?perPage=' + this.perPage + '&page=' + this.currentPage + '&buscar=' + this.buscar).then(function (res) {
        _this2.arrayMedicamentos = res.data.data;
        _this2.totalRows = res.data.total;
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this2.overlayTable = false;
      });
    },
    guardarMedicamento: function guardarMedicamento() {
      var _this3 = this;

      this.overlayStorage = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/guardarMedicamento', {
        'id': this.objMedicamento.id,
        'tipo': this.objMedicamento.tipo,
        'lote': this.objMedicamento.lote,
        'venta': this.objMedicamento.venta,
        'compra': this.objMedicamento.compra,
        'medida': this.objMedicamento.medida,
        'nombre': this.objMedicamento.nombre,
        'proveedor': this.objMedicamento.proveedor,
        'categoria': this.objMedicamento.categoria,
        'sanitario': this.objMedicamento.sanitario,
        'fabricante': this.objMedicamento.fabricante,
        'comentario': this.objMedicamento.comentario,
        'descripcion': this.objMedicamento.descripcion,
        'concentracion': this.objMedicamento.concentracion
      }).then(function (res) {
        _this3.listarMedicamento();

        _this3.modalStorage = false;

        _this3.pop_up('Éxito', 'Guardado Correctamente', 'success');
      })["catch"](function (err) {
        console.log(err);
        if (err.response.status == 422) _this3.pop_up('Error', 'Debe llenar los campos obligatorios', 'error');else _this3.pop_up('Error', 'no se puedo Guardar', 'error');
      })["finally"](function () {
        _this3.overlayStorage = false;
      });
    },
    listarSelectMedicamento: function listarSelectMedicamento() {
      var _this4 = this;

      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarSelectMedicamento').then(function (res) {
        _this4.cardarDatos(res.data);
      })["catch"](function (err) {
        console.log(err);
      });
    },
    cardarDatos: function cardarDatos(data) {
      for (var index = 0; index < data['pro'].length; index++) {
        this.arrayProveedores.push({
          value: data['pro'][index].id_proveedor,
          text: data['pro'][index].pro_razon_social
        });
      }

      for (var _index = 0; _index < data['fab'].length; _index++) {
        this.arrayFabricantes.push({
          value: data['fab'][_index].id_fabricante,
          text: data['fab'][_index].fa_nombre
        });
      }

      for (var _index2 = 0; _index2 < data['cat'].length; _index2++) {
        this.arrayCategorias.push({
          value: data['cat'][_index2].id_categoria,
          text: data['cat'][_index2].c_nombre
        });
      }

      for (var _index3 = 0; _index3 < data['tip'].length; _index3++) {
        this.arrayTipos.push({
          value: data['tip'][_index3].id_tipo,
          text: data['tip'][_index3].t_nombre
        });
      }

      for (var _index4 = 0; _index4 < data['med'].length; _index4++) {
        this.arrayMedidas.push({
          value: data['med'][_index4].id_unidad_medida,
          text: data['med'][_index4].um_nombre
        });
      }
    },
    cambiarEstadoMedicamento: function cambiarEstadoMedicamento(item) {
      var _this5 = this;

      this.overlayTable = true;
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/cambiarEstadoMedicamento', {
        'id': item.id_medicamento,
        'estado': item.med_activo == 1 ? 0 : 1
      }).then(function (res) {
        _this5.listarMedicamento();

        _this5.pop_up('Éxito', 'Guardado Correctamente', 'success');
      })["catch"](function (err) {
        console.log(err);
        _this5.overlayTable = false;
        if (err.response.status == 422) _this5.pop_up('Error', 'Debe llenar los campos obligatorios', 'error');else _this5.pop_up('Error', 'no se puedo Guardar', 'error');
      });
    },
    abrirModalImagen: function abrirModalImagen(item) {
      var _this6 = this;

      var url = location.protocol + "//" + location.host + "/FotoMedicamento" + "/" + item.id_medicamento + ".jpg";
      this.verificarImagen(url).then(function () {
        console.log('La imagen existe');
        _this6.image = url;
        _this6.src = url;
      })["catch"](function () {
        console.log('La imagen no existe');
        _this6.image = '';
        _this6.src = __webpack_require__(/*! @/assets/fridosa/medicamento.png */ "./resources/js/src/assets/fridosa/medicamento.png");
      });
      this.showImage = true;
      this.medicamento = item.id_medicamento;
    },
    verificarImagen: function verificarImagen(url) {
      return new Promise(function (resolve, reject) {
        var img = new Image();

        img.onload = function () {
          resolve();
        };

        img.onerror = function () {
          reject();
        };

        img.src = url;
      });
    },
    obtenerImagen: function obtenerImagen(e) {
      var file = e.target.files[0];
      this.imageEnviar = file;
      this.cargarImagen(file);
    },
    cargarImagen: function cargarImagen(file) {
      var _this7 = this;

      var reader = new FileReader();

      reader.onload = function (e) {
        _this7.image = e.target.result;
      };

      reader.readAsDataURL(file);
    },
    imagenStore: function imagenStore() {
      var _this8 = this;

      this.overlayImage = true;
      var formData = new FormData();
      formData.append('imageEnviar[]', this.imageEnviar);
      formData.append('medicamento', this.medicamento);
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.post('/photoStoreMed', formData).then(function (res) {
        _this8.cerrar();

        _this8.pop_up('Éxito', 'Imagen guardada correctamente', 'success');

        _this8.listarMedicamento();

        _this8.overlayImage = false;
      })["catch"](function (err) {
        console.log(err.response);
        _this8.overlayImage = false;

        _this8.pop_up('Error', 'Ocurrio un error al guardar imagen', 'error');
      });
    },
    cerrar: function cerrar() {
      this.src = __webpack_require__(/*! @/assets/fridosa/medicamento.png */ "./resources/js/src/assets/fridosa/medicamento.png");
      this.showImage = false;
      this.imageEnviar = '';
      this.medicamento = 0;
      this.image = '';
    },
    pop_up: function pop_up(title, text, icon) {
      this.$swal({
        title: title,
        text: text,
        icon: icon,
        showConfirmButton: false,
        timer: 2000,
        customClass: {
          confirmButton: 'btn btn-primary'
        },
        buttonsStyling: false
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/Medicamento.vue?vue&type=template&id=e39d053e&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Farmacia/Medicamento.vue?vue&type=template&id=e39d053e& ***!
  \**********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-card",
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-button",
                    {
                      attrs: { variant: "outline-success" },
                      on: {
                        click: function ($event) {
                          return _vm.abrirModal(null)
                        },
                      },
                    },
                    [_vm._v(" Nuevo Medicamento ")]
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-input-group",
                    [
                      _c("b-form-input", {
                        attrs: { placeholder: "Buscar...", state: true },
                        model: {
                          value: _vm.buscar,
                          callback: function ($$v) {
                            _vm.buscar = $$v
                          },
                          expression: "buscar",
                        },
                      }),
                      _vm._v(" "),
                      _c(
                        "b-input-group-append",
                        [
                          _c(
                            "b-button",
                            {
                              attrs: { variant: "outline-success" },
                              on: {
                                click: function ($event) {
                                  return _vm.listarMedicamento()
                                },
                              },
                            },
                            [_vm._v(" Buscar ")]
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayTable,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c("b-table", {
            attrs: {
              hover: "",
              striped: "",
              responsive: "",
              bordered: "",
              small: "",
              "no-border-collapse": "",
              items: _vm.arrayMedicamentos,
              fields: _vm.fields,
            },
            scopedSlots: _vm._u([
              {
                key: "cell(med_activo)",
                fn: function (data) {
                  return [
                    _c(
                      "b-badge",
                      {
                        attrs: { variant: _vm.estado[1][data.item.med_activo] },
                      },
                      [
                        _vm._v(
                          "\n                    " +
                            _vm._s(_vm.estado[0][data.item.med_activo]) +
                            "\n                "
                        ),
                      ]
                    ),
                  ]
                },
              },
              {
                key: "cell(opcion)",
                fn: function (data) {
                  return [
                    _c(
                      "b-button",
                      {
                        staticClass: "btn-icon rounded-circle text-center",
                        attrs: {
                          variant: data.item.med_activo
                            ? "flat-danger"
                            : "flat-success",
                          title: data.item.med_activo
                            ? "desactivar"
                            : "activar",
                        },
                        on: {
                          click: function ($event) {
                            return _vm.cambiarEstadoMedicamento(data.item)
                          },
                        },
                      },
                      [
                        _c("feather-icon", {
                          attrs: {
                            icon: data.item.med_activo
                              ? "LockIcon"
                              : "UnlockIcon",
                          },
                        }),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-button",
                      {
                        staticClass: "btn-icon rounded-circle text-center",
                        attrs: { variant: "flat-info", title: "editar" },
                        on: {
                          click: function ($event) {
                            return _vm.abrirModal(data.item)
                          },
                        },
                      },
                      [_c("feather-icon", { attrs: { icon: "EditIcon" } })],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-button",
                      {
                        staticClass: "btn-icon rounded-circle text-center",
                        attrs: { variant: "flat-primary", title: "imagen" },
                        on: {
                          click: function ($event) {
                            return _vm.abrirModalImagen(data.item)
                          },
                        },
                      },
                      [_c("feather-icon", { attrs: { icon: "ImageIcon" } })],
                      1
                    ),
                  ]
                },
              },
            ]),
          }),
          _vm._v(" "),
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { cols: "2" } },
                [
                  _c(
                    "b-form-group",
                    { staticClass: "mb-0" },
                    [
                      _c(
                        "label",
                        { staticClass: "d-inline-block text-sm-left mr-50" },
                        [_vm._v("Por página")]
                      ),
                      _vm._v(" "),
                      _c("b-form-select", {
                        staticClass: "w-50",
                        attrs: { size: "sm", options: _vm.pageOptions },
                        on: {
                          input: function ($event) {
                            return _vm.listarMedicamento()
                          },
                        },
                        model: {
                          value: _vm.perPage,
                          callback: function ($$v) {
                            _vm.perPage = $$v
                          },
                          expression: "perPage",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-col", { attrs: { cols: "10" } }, [
                _c(
                  "span",
                  { staticStyle: { float: "right" } },
                  [
                    _c("b-pagination", {
                      staticClass: "my-0",
                      attrs: {
                        "total-rows": _vm.totalRows,
                        "per-page": _vm.perPage,
                        align: "center",
                        size: "sm",
                      },
                      model: {
                        value: _vm.currentPage,
                        callback: function ($$v) {
                          _vm.currentPage = $$v
                        },
                        expression: "currentPage",
                      },
                    }),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: {
            "hide-footer": "",
            centered: "",
            title: _vm.title,
            size: "lg",
          },
          model: {
            value: _vm.modalStorage,
            callback: function ($$v) {
              _vm.modalStorage = $$v
            },
            expression: "modalStorage",
          },
        },
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-row",
                    [
                      _c(
                        "b-col",
                        { attrs: { md: "12" } },
                        [
                          _c(
                            "b-form-group",
                            [
                              _c("label", [_vm._v(" Nombre ")]),
                              _vm._v(" "),
                              _c("b-form-input", {
                                attrs: {
                                  placeholder: "Nombre",
                                  state: _vm.objMedicamento.nombre != null,
                                },
                                model: {
                                  value: _vm.objMedicamento.nombre,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.objMedicamento, "nombre", $$v)
                                  },
                                  expression: "objMedicamento.nombre",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "b-col",
                        { attrs: { md: "12" } },
                        [
                          _c(
                            "b-form-group",
                            [
                              _c("label", [_vm._v(" Proveedor ")]),
                              _vm._v(" "),
                              _c("b-form-select", {
                                attrs: {
                                  options: _vm.arrayProveedores,
                                  state: _vm.objMedicamento.proveedor != null,
                                },
                                model: {
                                  value: _vm.objMedicamento.proveedor,
                                  callback: function ($$v) {
                                    _vm.$set(
                                      _vm.objMedicamento,
                                      "proveedor",
                                      $$v
                                    )
                                  },
                                  expression: "objMedicamento.proveedor",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "b-col",
                        { attrs: { md: "12" } },
                        [
                          _c(
                            "b-form-group",
                            [
                              _c("label", [_vm._v(" Fabricante ")]),
                              _vm._v(" "),
                              _c("b-form-select", {
                                attrs: {
                                  options: _vm.arrayFabricantes,
                                  state: _vm.objMedicamento.fabricante != null,
                                },
                                model: {
                                  value: _vm.objMedicamento.fabricante,
                                  callback: function ($$v) {
                                    _vm.$set(
                                      _vm.objMedicamento,
                                      "fabricante",
                                      $$v
                                    )
                                  },
                                  expression: "objMedicamento.fabricante",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-col", { attrs: { md: "6" } }, [
                _c("span", { staticStyle: { "font-size": "0.9rem" } }, [
                  _vm._v(" Imagen Medicamento "),
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    staticClass: "text-center",
                    staticStyle: { width: "100%", height: "195px" },
                  },
                  [
                    _vm.image !== ""
                      ? _c("img", {
                          staticClass: "d-inline-block border",
                          staticStyle: {
                            width: "100%",
                            height: "100%",
                            "object-fit": "cover",
                          },
                          attrs: { src: _vm.imagen, alt: "Previsualización" },
                        })
                      : _c("img", {
                          staticClass: "d-inline-block border",
                          staticStyle: {
                            width: "100%",
                            height: "100%",
                            "object-fit": "cover",
                          },
                          attrs: { src: _vm.src, alt: "Previsualización" },
                        }),
                  ]
                ),
              ]),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "4" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Categoría ")]),
                      _vm._v(" "),
                      _c("b-form-select", {
                        attrs: {
                          options: _vm.arrayCategorias,
                          state: _vm.objMedicamento.categoria != null,
                        },
                        model: {
                          value: _vm.objMedicamento.categoria,
                          callback: function ($$v) {
                            _vm.$set(_vm.objMedicamento, "categoria", $$v)
                          },
                          expression: "objMedicamento.categoria",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "4" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Tipo ")]),
                      _vm._v(" "),
                      _c("b-form-select", {
                        attrs: {
                          options: _vm.arrayTipos,
                          state: _vm.objMedicamento.tipo != null,
                        },
                        model: {
                          value: _vm.objMedicamento.tipo,
                          callback: function ($$v) {
                            _vm.$set(_vm.objMedicamento, "tipo", $$v)
                          },
                          expression: "objMedicamento.tipo",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "4" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Unidad de Medida ")]),
                      _vm._v(" "),
                      _c("b-form-select", {
                        attrs: {
                          options: _vm.arrayMedidas,
                          state: _vm.objMedicamento.medida != null,
                        },
                        model: {
                          value: _vm.objMedicamento.medida,
                          callback: function ($$v) {
                            _vm.$set(_vm.objMedicamento, "medida", $$v)
                          },
                          expression: "objMedicamento.medida",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Comentario ")]),
                      _vm._v(" "),
                      _c("b-form-textarea", {
                        attrs: {
                          rows: "3",
                          placeholder: "Comentario",
                          state: _vm.objMedicamento.comentario != null,
                        },
                        model: {
                          value: _vm.objMedicamento.comentario,
                          callback: function ($$v) {
                            _vm.$set(_vm.objMedicamento, "comentario", $$v)
                          },
                          expression: "objMedicamento.comentario",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Descripción ")]),
                      _vm._v(" "),
                      _c("b-form-textarea", {
                        attrs: { rows: "3", placeholder: "Descripción" },
                        model: {
                          value: _vm.objMedicamento.descripcion,
                          callback: function ($$v) {
                            _vm.$set(_vm.objMedicamento, "descripcion", $$v)
                          },
                          expression: "objMedicamento.descripcion",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "4" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Nº Lote ")]),
                      _vm._v(" "),
                      _c("b-form-input", {
                        attrs: { placeholder: "Lote" },
                        model: {
                          value: _vm.objMedicamento.lote,
                          callback: function ($$v) {
                            _vm.$set(_vm.objMedicamento, "lote", $$v)
                          },
                          expression: "objMedicamento.lote",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "4" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Concentración ")]),
                      _vm._v(" "),
                      _c("b-form-input", {
                        attrs: { placeholder: "Concentración" },
                        model: {
                          value: _vm.objMedicamento.concentracion,
                          callback: function ($$v) {
                            _vm.$set(_vm.objMedicamento, "concentracion", $$v)
                          },
                          expression: "objMedicamento.concentracion",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "4" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Registro Sanitario ")]),
                      _vm._v(" "),
                      _c("b-form-input", {
                        attrs: { placeholder: "Registro Sanitario" },
                        model: {
                          value: _vm.objMedicamento.sanitario,
                          callback: function ($$v) {
                            _vm.$set(_vm.objMedicamento, "sanitario", $$v)
                          },
                          expression: "objMedicamento.sanitario",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-col", { attrs: { md: "3" } }),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "3" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Precio Compra ")]),
                      _vm._v(" "),
                      _c("b-form-input", {
                        attrs: { type: "number", placeholder: "0" },
                        model: {
                          value: _vm.objMedicamento.compra,
                          callback: function ($$v) {
                            _vm.$set(_vm.objMedicamento, "compra", $$v)
                          },
                          expression: "objMedicamento.compra",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { md: "3" } },
                [
                  _c(
                    "b-form-group",
                    [
                      _c("label", [_vm._v(" Precio Venta ")]),
                      _vm._v(" "),
                      _c("b-form-input", {
                        attrs: { type: "number", placeholder: "0" },
                        model: {
                          value: _vm.objMedicamento.venta,
                          callback: function ($$v) {
                            _vm.$set(_vm.objMedicamento, "venta", $$v)
                          },
                          expression: "objMedicamento.venta",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-col", { attrs: { md: "3" } }),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayStorage,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-left",
              attrs: { variant: "outline-danger" },
              on: {
                click: function ($event) {
                  _vm.modalStorage = false
                },
              },
            },
            [_vm._v(" Cancelar ")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              staticClass: "float-right",
              attrs: { variant: "outline-success" },
              on: {
                click: function ($event) {
                  return _vm.guardarMedicamento()
                },
              },
            },
            [_vm._v(" Guardar ")]
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: {
            centered: "",
            title: "CAMBIAR IMAGEN",
            "hide-footer": "",
            size: "xs",
          },
          model: {
            value: _vm.showImage,
            callback: function ($$v) {
              _vm.showImage = $$v
            },
            expression: "showImage",
          },
        },
        [
          _c("div", { staticClass: "form-floating my-1" }, [
            _c("form", { attrs: { enctype: "multipart/form-data" } }, [
              _c(
                "div",
                [
                  _c("b-form-file", {
                    attrs: {
                      id: "file",
                      accept: "image/*",
                      placeholder: "Cargar Imagen",
                      "browse-text": "Seleccionar",
                    },
                    on: { change: _vm.obtenerImagen },
                  }),
                ],
                1
              ),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "text-center" }, [
            _vm.image != ""
              ? _c("img", {
                  staticClass: "d-inline-block border",
                  attrs: {
                    src: _vm.imagen,
                    alt: "Previsualización",
                    width: "150",
                    height: "150",
                  },
                })
              : _c("img", {
                  staticClass: "d-inline-block border",
                  attrs: {
                    src: _vm.src,
                    alt: "Previsualización",
                    width: "150",
                    height: "150",
                  },
                }),
          ]),
          _vm._v(" "),
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayImage,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { cols: "6" } },
                [
                  _c(
                    "b-button",
                    {
                      staticClass: "float-left",
                      attrs: {
                        variant: "outline-danger",
                        disabled: _vm.overlayImage,
                      },
                      on: {
                        click: function ($event) {
                          return _vm.cerrar()
                        },
                      },
                    },
                    [_vm._v(" Cancelar ")]
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { attrs: { cols: "6" } },
                [
                  _c(
                    "b-button",
                    {
                      staticClass: "float-right",
                      attrs: {
                        variant: "outline-success",
                        disabled: _vm.overlayImage,
                      },
                      on: {
                        click: function ($event) {
                          return _vm.imagenStore()
                        },
                      },
                    },
                    [_vm._v(" Guardar ")]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/assets/fridosa/medicamento.jpg":
/*!*********************************************************!*\
  !*** ./resources/js/src/assets/fridosa/medicamento.jpg ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/WEB_MODULOS (1)/resources/js/src/assets/fridosa/medicamento.jpg";

/***/ }),

/***/ "./resources/js/src/assets/fridosa/medicamento.png":
/*!*********************************************************!*\
  !*** ./resources/js/src/assets/fridosa/medicamento.png ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/WEB_MODULOS (1)/resources/js/src/assets/fridosa/medicamento.png";

/***/ }),

/***/ "./resources/js/src/views/Farmacia/Medicamento.vue":
/*!*********************************************************!*\
  !*** ./resources/js/src/views/Farmacia/Medicamento.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Medicamento_vue_vue_type_template_id_e39d053e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Medicamento.vue?vue&type=template&id=e39d053e& */ "./resources/js/src/views/Farmacia/Medicamento.vue?vue&type=template&id=e39d053e&");
/* harmony import */ var _Medicamento_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Medicamento.vue?vue&type=script&lang=js& */ "./resources/js/src/views/Farmacia/Medicamento.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Medicamento_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Medicamento_vue_vue_type_template_id_e39d053e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Medicamento_vue_vue_type_template_id_e39d053e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/Farmacia/Medicamento.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/Farmacia/Medicamento.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/src/views/Farmacia/Medicamento.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Medicamento_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Medicamento.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/Medicamento.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Medicamento_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/Farmacia/Medicamento.vue?vue&type=template&id=e39d053e&":
/*!****************************************************************************************!*\
  !*** ./resources/js/src/views/Farmacia/Medicamento.vue?vue&type=template&id=e39d053e& ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Medicamento_vue_vue_type_template_id_e39d053e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Medicamento.vue?vue&type=template&id=e39d053e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Farmacia/Medicamento.vue?vue&type=template&id=e39d053e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Medicamento_vue_vue_type_template_id_e39d053e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Medicamento_vue_vue_type_template_id_e39d053e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);