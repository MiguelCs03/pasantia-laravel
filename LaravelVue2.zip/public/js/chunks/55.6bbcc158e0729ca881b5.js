(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[55],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Reporte/Fraccionamiento.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Reporte/Fraccionamiento.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      // paginación
      pageOptions: [50, 100, 200, 500],
      currentPage: 1,
      totalRows: 1,
      perPage: 50,
      overlayTable: false,
      arrayFraccionamiento: [],
      fields: [{
        key: 'codDocAlm',
        label: 'cod. alm.'
      }, {
        key: 'codAlmFri',
        label: 'alm. fri.'
      }, {
        key: 'fecFra',
        label: 'fecha'
      }, {
        key: 'numSeq',
        label: 'secuencia'
      }, {
        key: 'codRes',
        label: 'cod. res.'
      }, {
        key: 'PesIni',
        label: 'pes. ini'
      }, {
        key: 'pesoCalculo',
        label: 'peso'
      }, {
        key: 'numeroPar',
        label: 'número'
      }, {
        key: 'va_ide1_cli',
        label: 'va_ide1'
      }, {
        key: 'va_ide2_cli',
        label: 'va_ide2'
      }, {
        key: 'va_ide3_cli',
        label: 'va_ide3'
      }, {
        key: 'va_ide4_cli',
        label: 'va_ide4'
      }],
      buscar: '',
      desde: null,
      hasta: null
    };
  },
  mounted: function mounted() {
    this.desde = this.$moment().startOf('month').format('YYYY-MM-DD');
    this.hasta = this.$moment().format('YYYY-MM-DD');
    this.listarFraccionamiento();
  },
  watch: {
    currentPage: function currentPage(newPage) {
      this.currentPage = newPage;
      this.listarFraccionamiento();
    }
  },
  methods: {
    listarFraccionamiento: function listarFraccionamiento() {
      var _this = this;

      this.overlayTable = true;
      this.arrayFraccionamiento = [];
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token');
      this.axios.get('/listarFraccionamiento?perPage=' + this.perPage + '&page=' + this.currentPage + '&buscar=' + this.buscar + '&fecha_inicio=' + this.desde + '&fecha_fin=' + this.hasta).then(function (res) {
        _this.arrayFraccionamiento = res.data.data;
        _this.totalRows = res.data.total;
      })["catch"](function (err) {
        console.log(err);
      })["finally"](function () {
        _this.overlayTable = false;
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Reporte/Fraccionamiento.vue?vue&type=template&id=73362f54&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Reporte/Fraccionamiento.vue?vue&type=template&id=73362f54& ***!
  \*************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-card",
        [
          _c(
            "b-row",
            [
              _c("b-col", { attrs: { md: "12" } }, [
                _c(
                  "div",
                  { staticClass: "d-flex align-items-center float-right" },
                  [
                    _c("b-form-input", {
                      attrs: { placeholder: "Buscar...", state: true },
                      model: {
                        value: _vm.buscar,
                        callback: function ($$v) {
                          _vm.buscar = $$v
                        },
                        expression: "buscar",
                      },
                    }),
                    _vm._v(" "),
                    _c("b-form-datepicker", {
                      staticClass: "ml-2",
                      attrs: {
                        "date-format-options": {
                          year: "numeric",
                          month: "numeric",
                          day: "numeric",
                        },
                        "selected-variant": "primary",
                        "button-variant": "primary",
                        state: true,
                      },
                      model: {
                        value: _vm.desde,
                        callback: function ($$v) {
                          _vm.desde = $$v
                        },
                        expression: "desde",
                      },
                    }),
                    _vm._v(" "),
                    _c("b-form-datepicker", {
                      staticClass: "mx-2",
                      attrs: {
                        "date-format-options": {
                          year: "numeric",
                          month: "numeric",
                          day: "numeric",
                        },
                        "selected-variant": "primary",
                        "button-variant": "primary",
                        state: true,
                      },
                      model: {
                        value: _vm.hasta,
                        callback: function ($$v) {
                          _vm.hasta = $$v
                        },
                        expression: "hasta",
                      },
                    }),
                    _vm._v(" "),
                    _c(
                      "b-button",
                      {
                        attrs: { variant: "outline-success" },
                        on: {
                          click: function ($event) {
                            return _vm.listarFraccionamiento()
                          },
                        },
                      },
                      [
                        _c("feather-icon", {
                          attrs: { icon: "SearchIcon", size: "16" },
                        }),
                      ],
                      1
                    ),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-card",
        [
          _c("b-overlay", {
            attrs: {
              show: _vm.overlayTable,
              rounded: "sm",
              variant: "info",
              opacity: "0.2",
              "no-wrap": "",
            },
          }),
          _vm._v(" "),
          _c("b-table", {
            attrs: {
              hover: "",
              striped: "",
              responsive: "",
              bordered: "",
              small: "",
              "no-border-collapse": "",
              items: _vm.arrayFraccionamiento,
              fields: _vm.fields,
            },
          }),
          _vm._v(" "),
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { cols: "2" } },
                [
                  _c(
                    "b-form-group",
                    { staticClass: "mb-0" },
                    [
                      _c(
                        "label",
                        { staticClass: "d-inline-block text-sm-left mr-50" },
                        [_vm._v("Por página")]
                      ),
                      _vm._v(" "),
                      _c("b-form-select", {
                        staticClass: "w-50",
                        attrs: { size: "sm", options: _vm.pageOptions },
                        on: {
                          input: function ($event) {
                            return _vm.listarFraccionamiento()
                          },
                        },
                        model: {
                          value: _vm.perPage,
                          callback: function ($$v) {
                            _vm.perPage = $$v
                          },
                          expression: "perPage",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-col", { attrs: { cols: "10" } }, [
                _c(
                  "span",
                  { staticStyle: { float: "right" } },
                  [
                    _c("b-pagination", {
                      staticClass: "my-0",
                      attrs: {
                        "total-rows": _vm.totalRows,
                        "per-page": _vm.perPage,
                        align: "center",
                        size: "sm",
                      },
                      model: {
                        value: _vm.currentPage,
                        callback: function ($$v) {
                          _vm.currentPage = $$v
                        },
                        expression: "currentPage",
                      },
                    }),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/Reporte/Fraccionamiento.vue":
/*!************************************************************!*\
  !*** ./resources/js/src/views/Reporte/Fraccionamiento.vue ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Fraccionamiento_vue_vue_type_template_id_73362f54___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Fraccionamiento.vue?vue&type=template&id=73362f54& */ "./resources/js/src/views/Reporte/Fraccionamiento.vue?vue&type=template&id=73362f54&");
/* harmony import */ var _Fraccionamiento_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Fraccionamiento.vue?vue&type=script&lang=js& */ "./resources/js/src/views/Reporte/Fraccionamiento.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Fraccionamiento_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Fraccionamiento_vue_vue_type_template_id_73362f54___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Fraccionamiento_vue_vue_type_template_id_73362f54___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/Reporte/Fraccionamiento.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/Reporte/Fraccionamiento.vue?vue&type=script&lang=js&":
/*!*************************************************************************************!*\
  !*** ./resources/js/src/views/Reporte/Fraccionamiento.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Fraccionamiento_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Fraccionamiento.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Reporte/Fraccionamiento.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Fraccionamiento_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/Reporte/Fraccionamiento.vue?vue&type=template&id=73362f54&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/src/views/Reporte/Fraccionamiento.vue?vue&type=template&id=73362f54& ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Fraccionamiento_vue_vue_type_template_id_73362f54___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Fraccionamiento.vue?vue&type=template&id=73362f54& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Reporte/Fraccionamiento.vue?vue&type=template&id=73362f54&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Fraccionamiento_vue_vue_type_template_id_73362f54___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Fraccionamiento_vue_vue_type_template_id_73362f54___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);