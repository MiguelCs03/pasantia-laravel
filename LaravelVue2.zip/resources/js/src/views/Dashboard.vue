<template>
  <div>
    <H1>HOLA MUNDO </H1>
  </div>
</template>

<script>
import { BCard, BCardText, BCol, BRow } from 'bootstrap-vue'


export default {
  components: {
    BCol,
    BRow,
    BCard,
    BCardText,

  },
};
</script>

