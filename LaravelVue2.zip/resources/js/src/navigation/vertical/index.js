export default [
  // {
  //   title: 'Inicio',
  //   route: 'Inicio',
  //   icon: 'HomeIcon',
  // },
  // {
  //   title: 'Publicaciones',
  //   route: 'Publicaciones',
  //   icon: 'ClipboardIcon',
  // },
  // {
  //   title: 'Postulaciones',
  //   route: 'Postulacion',
  //   icon: 'ClipboardIcon',
  // },  
  // {
  //   title: 'Encuesta',
  //   route: 'Encuesta',
  //   icon: 'ClipboardIcon',
  // },
  // {
  //   title: 'Logout',
  //   route: 'Portal',
  //   icon: 'ClipboardIcon',
  // },
  // {
  //   title: 'Portal',
  //   route: 'Portal',
  //   icon: 'TrelloIcon',
  // },
]
